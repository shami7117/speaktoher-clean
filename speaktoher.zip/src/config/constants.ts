export const TESTIMONIALS = [
  '"I thought it was a joke... until I got exactly what I asked for." — Mike G',
  '"I\'m literally crying. This was divine." — Mary M',
  '"It said *exactly* what I needed to hear. No way this is random." — Josh T',
  '"I felt seen. I\'ve never experienced anything like this." — Leah R',
  '"I got chills. This felt holy." — Daniel F',
]

export const VERSES = [
  "Isaiah — But those who hope in the Lord will renew their strength...",
  "Psalm — The Lord is close to the brokenhearted and saves those who are crushed in spirit.",
  "Romans — alsdkjf f;a f;kdfj;akjdf;ajf;",
]
