import React from "react"

const EmailTestComponent = () => {
  return <div>EmailTestComponent</div>
}

export default EmailTestComponent
