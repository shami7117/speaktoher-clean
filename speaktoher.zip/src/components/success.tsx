import React from "react"

const success = () => {
  return <div>success</div>
}

export default success
