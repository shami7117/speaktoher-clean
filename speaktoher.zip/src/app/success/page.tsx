import SuccessPage from "@/components/success"
import React from "react"

export const dynamic = "force-dynamic"

const page = () => {
  return <SuccessPage />
}

export default page
