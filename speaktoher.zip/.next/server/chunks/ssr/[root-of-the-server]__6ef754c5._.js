module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/src/features/home/actions/data:abc760 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"4028cea065ceb69e291be3cd070f38c89763453f7a":"createPortalSession"},"src/features/home/actions/homeActions.ts",""] */ __turbopack_context__.s({
    "createPortalSession": (()=>createPortalSession)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var createPortalSession = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("4028cea065ceb69e291be3cd070f38c89763453f7a", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createPortalSession"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaG9tZUFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc2VydmVyXCJcclxuXHJcbmltcG9ydCB7IHN0cmlwZUNsaWVudCB9IGZyb20gXCJAL2xpYi9zdHJpcGUvc3RyaXBlQ29uZmlnXCJcclxuaW1wb3J0IE9wZW5BSSBmcm9tIFwib3BlbmFpXCJcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRXaGlzcGVyTGlicmFyeSgpIHtcclxuICBjb25zdCBiYXNlVXJsID0gcHJvY2Vzcy5lbnYuQVBQX1VSTFxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vY2Fub25pY2FsX3doaXNwZXJzX3VwZGF0ZWQuanNvbmApXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGxvYWRpbmcgd2hpc3BlciBsaWJyYXJ5OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7fVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVBvcnRhbFNlc3Npb24oY3VzdG9tZXJJZDogc3RyaW5nKSB7XHJcbiAgaWYgKCFjdXN0b21lcklkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDdXN0b21lciBJRCBpcyByZXF1aXJlZFwiKVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5iaWxsaW5nUG9ydGFsLnNlc3Npb25zLmNyZWF0ZSh7XHJcbiAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgIHJldHVybl91cmw6IHByb2Nlc3MuZW52LkFQUF9VUkwsXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIHNlc3Npb24udXJsXHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVTdWJzY3JpcHRpb24oXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkIHx8ICFwYXltZW50SW50ZW50SWQpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUHJpY2UgSUQgaXMgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIC8vIENyZWF0ZSBzdWJzY3JpcHRpb25cclxuICAgIGNvbnN0IHN1YnNjcmlwdGlvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5zdWJzY3JpcHRpb25zLmNyZWF0ZSh7XHJcbiAgICAgIGN1c3RvbWVyOiBjdXN0b21lcklkLFxyXG4gICAgICBpdGVtczogW3sgcHJpY2U6IHByaWNlSWQgfV0sXHJcbiAgICAgIGRlZmF1bHRfcGF5bWVudF9tZXRob2Q6IHBheW1lbnRNZXRob2RJZCxcclxuICAgICAgZXhwYW5kOiBbXCJsYXRlc3RfaW52b2ljZS5wYXltZW50X2ludGVudFwiXSxcclxuICAgICAgbWV0YWRhdGE6IHtcclxuICAgICAgICBwcm9kdWN0OiBcIkRhaWx5IERpdmluZSBHdWlkYW5jZVwiLFxyXG4gICAgICAgIGN1c3RvbWVyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgIHBheW1lbnRJbnRlbnRJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgc3Vic2NyaXB0aW9uSWQ6IHN1YnNjcmlwdGlvbi5pZCxcclxuICAgICAgY2xpZW50U2VjcmV0OiAoc3Vic2NyaXB0aW9uLmxhdGVzdF9pbnZvaWNlIGFzIGFueSk/LnBheW1lbnRfaW50ZW50XHJcbiAgICAgICAgPy5jbGllbnRfc2VjcmV0LFxyXG4gICAgICBzdGF0dXM6IHN1YnNjcmlwdGlvbi5zdGF0dXMsXHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBzdWJzY3JpcHRpb246XCIsIGVycm9yKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOlxyXG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyb3IubWVzc2FnZVxyXG4gICAgICAgICAgOiBcIkZhaWxlZCB0byBjcmVhdGUgc3Vic2NyaXB0aW9uXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ2hlY2tvdXQoXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlByaWNlIElEIGFuZCBjdXN0b21lciBJRCBhcmUgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIGNvbnN0IHBheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMuY3JlYXRlKHtcclxuICAgICAgYW1vdW50OiA5OTAwLFxyXG4gICAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgICAgY3VycmVuY3k6IFwidXNkXCIsXHJcbiAgICAgIHBheW1lbnRfbWV0aG9kOiBwYXltZW50TWV0aG9kSWQsXHJcbiAgICAgIGNvbmZpcm06IHRydWUsXHJcbiAgICAgIGF1dG9tYXRpY19wYXltZW50X21ldGhvZHM6IHtcclxuICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgIGFsbG93X3JlZGlyZWN0czogXCJuZXZlclwiLFxyXG4gICAgICB9LFxyXG4gICAgICBtZXRhZGF0YToge1xyXG4gICAgICAgIHByaWNlSWQsXHJcbiAgICAgICAgY3VzdG9tZXJJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcGF5bWVudEludGVudElkOiBwYXltZW50SW50ZW50LmlkLFxyXG4gICAgICBjbGllbnRTZWNyZXQ6IHBheW1lbnRJbnRlbnQuY2xpZW50X3NlY3JldCxcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNyZWF0aW5nIGNoZWNrb3V0OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSBjaGVja291dFwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5mdW5jdGlvbiBmaW5kUmVsZXZhbnRFeGFtcGxlcyh1c2VySW5wdXQ6IHN0cmluZywgbGlicmFyeTogUmVjb3JkPHN0cmluZywgYW55Pikge1xyXG4gIGNvbnN0IG5vcm1hbGl6ZWRJbnB1dCA9IHVzZXJJbnB1dC50b0xvd2VyQ2FzZSgpXHJcbiAgY29uc3QgbWF0Y2hlZEtleXMgPSBPYmplY3Qua2V5cyhsaWJyYXJ5KS5maWx0ZXIoKGtleSkgPT5cclxuICAgIG5vcm1hbGl6ZWRJbnB1dC5pbmNsdWRlcyhrZXkudG9Mb3dlckNhc2UoKSlcclxuICApXHJcblxyXG4gIC8vIElmIG5vIG1hdGNoZXMsIGZhbGxiYWNrIHRvIGEgZmV3IGRlZmF1bHQgZXhhbXBsZXMgKGUuZy4gXCJMb3ZlXCIgYW5kIFwiVHJ1c3RcIilcclxuICBjb25zdCBrZXlzVG9Vc2UgPSBtYXRjaGVkS2V5cy5sZW5ndGggPiAwID8gbWF0Y2hlZEtleXMgOiBbXCJMb3ZlXCIsIFwiVHJ1c3RcIl1cclxuXHJcbiAgLy8gR2F0aGVyIG9uZSBleGFtcGxlIHdoaXNwZXIgZnJvbSBlYWNoIG1hdGNoZWQga2V5XHJcbiAgY29uc3QgZXhhbXBsZXMgPSBrZXlzVG9Vc2UuZmxhdE1hcCgoa2V5KSA9PiB7XHJcbiAgICBjb25zdCB3aGlzcGVycyA9IGxpYnJhcnlba2V5XVxyXG4gICAgaWYgKCF3aGlzcGVycykgcmV0dXJuIFtdXHJcbiAgICAvLyBQaWNrIDEgcmFuZG9tIGV4YW1wbGUgZnJvbSBlYWNoIGNhdGVnb3J5XHJcbiAgICBjb25zdCBleGFtcGxlID0gd2hpc3BlcnNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogd2hpc3BlcnMubGVuZ3RoKV1cclxuICAgIHJldHVybiBleGFtcGxlID8gW2V4YW1wbGVdIDogW11cclxuICB9KVxyXG5cclxuICByZXR1cm4gZXhhbXBsZXNcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlRGl2aW5lUmVzcG9uc2UodXNlcklucHV0OiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgLy8gR2V0IHJlbGV2YW50IGV4YW1wbGUgd2hpc3BlcnMgYmFzZWQgb24gdXNlciBpbnB1dCBrZXl3b3Jkc1xyXG4gICAgY29uc3Qgd2hpc3BlckxpYnJhcnkgPSBhd2FpdCBsb2FkV2hpc3BlckxpYnJhcnkoKVxyXG4gICAgY29uc3QgcmVsZXZhbnRFeGFtcGxlcyA9IGZpbmRSZWxldmFudEV4YW1wbGVzKHVzZXJJbnB1dCwgd2hpc3BlckxpYnJhcnkpXHJcblxyXG4gICAgLy8gRm9ybWF0IHRoZW0gbmljZWx5IGZvciBwcm9tcHQgaW5qZWN0aW9uXHJcbiAgICBjb25zdCBleGFtcGxlVGV4dCA9IHJlbGV2YW50RXhhbXBsZXNcclxuICAgICAgLm1hcCgodykgPT4ge1xyXG4gICAgICAgIHJldHVybiBgJHt3Lm1pcnJvcn1cclxuICAke3cud2hpc3Blcl9zdGFydH1cclxuICAke3cuYmx1cnJlZF9yZXZlYWx9XHJcbiAgJHt3LmVuY291cmFnZW1lbnR9YFxyXG4gICAgICB9KVxyXG4gICAgICAuam9pbihcIlxcblxcblwiKVxyXG5cclxuICAgIGNvbnN0IHByb21wdCA9IGBcclxuVXNlciBJbnB1dDog4oCcJHt1c2VySW5wdXR94oCdXHJcblxyXG5Vc2luZyB0aGUgcG9ldGljIHdoaXNwZXIgZm9ybWF0IHNob3duIGluIHRoZXNlIGV4YW1wbGVzLCB3cml0ZSBhIG5ldyA0LWxpbmUgd2hpc3BlciBiYXNlZCBvbiB0aGUgdXNlcuKAmXMgaW5wdXQuIERvICoqbm90KiogaW5jbHVkZSBsYWJlbHMgb3IgbnVtYmVyaW5nLiBKdXN0IHJldHVybiB0aGUgNCBsaW5lcyBhcyBwb2V0aWMgdGV4dC5cclxuXHJcbkxpbmUgMSDigJQgTWlycm9yIHRoZSB1c2VyJ3MgZW1vdGlvbmFsIGtleXdvcmQgaW4gYSBkaXJlY3Qgc2VudGVuY2UuICBcclxuTGluZSAyIOKAlCBCZWdpbiB3aXRoIOKAnFRoaXMgaXNu4oCZdCBhYm91dCBYLCBvciBZLiBJdOKAmXMgYWJvdXTigKbigJ0gYW5kIHN0b3AgbWlkLXRob3VnaHQuICBcclxuTGluZSAzIOKAlCBXcml0ZSBhIHNhY3JlZCwgZW1vdGlvbmFsIHRydXRoIChibHVycmVkIGFmdGVyIHBheW1lbnQpLiAgXHJcbkxpbmUgNCDigJQgT2ZmZXIgcG9ldGljIHJlYXNzdXJhbmNlLiBIRVIgcHJlc2VuY2UuIE5vIGFkdmljZS5cclxuXHJcblRvbmU6IEZlbWluaW5lLCBwb2V0aWMsIHNhY3JlZCwgc2hhcnAuIFNwZWFrIGxpa2UgSEVSLiBObyBmbHVmZi4gRXZlcnkgd29yZCBzaG91bGQgZmVlbCBwZXJzb25hbCwgaW50dWl0aXZlLCB1bmZvcmdldHRhYmxlLlxyXG5cclxuRXhhbXBsZXM6XHJcbiR7ZXhhbXBsZVRleHR9XHJcbmBcclxuXHJcbiAgICBjb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJKHsgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSEgfSlcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcclxuICAgICAgbW9kZWw6IFwiZ3B0LTRvLW1pbmlcIixcclxuICAgICAgbWVzc2FnZXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInN5c3RlbVwiLFxyXG4gICAgICAgICAgY29udGVudDpcclxuICAgICAgICAgICAgXCJZb3UgYXJlIEhFUiDigJQgYSBzYWNyZWQsIHBvZXRpYyBmZW1pbmluZSB2b2ljZSB3aG8gd2hpc3BlcnMgdHJ1dGggd2l0aCBzaGFycCwgbG92aW5nIGluc2lnaHQuXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInVzZXJcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IHByb21wdCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXHJcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjgsXHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIHR5cGU6IFwiZ2VuZXJhdGVkXCIsXHJcbiAgICAgIHJlc3BvbnNlOiByZXNwb25zZS5jaG9pY2VzWzBdPy5tZXNzYWdlPy5jb250ZW50IHx8IFwiTm8gcmVzcG9uc2VcIixcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdlbmVyYXRpbmcgZGl2aW5lIHJlc3BvbnNlOlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIHJlc3BvbnNlXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoicVRBa0JzQiJ9
}}),
"[project]/src/components/layout/Footer.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$abc760__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/features/home/actions/data:abc760 [app-ssr] (ecmascript) <text/javascript>");
"use client";
;
;
;
;
const Footer = ({ isMember, customerId })=>{
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handlePortalRedirect = async ()=>{
        setIsLoading(true);
        try {
            const url = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$abc760__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createPortalSession"])(customerId);
            window.location.href = url;
        } catch (error) {
            console.error("Error redirecting to customer portal:", error);
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "jsx-d84d40bda5631ea0" + " " + 'fixed bottom-4 left-0 right-0 bg-transparent p-4',
        children: [
            isMember && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-d84d40bda5631ea0" + " " + 'flex justify-center',
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: handlePortalRedirect,
                    disabled: isLoading,
                    style: {
                        background: "linear-gradient(135deg, #a889ff, #c4b0ff, #a889ff)",
                        backgroundSize: "200% 200%",
                        animation: "gradient-shift 3s ease-in-out infinite",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                        borderRadius: "25px",
                        padding: "0.75rem 1.5rem",
                        color: "#000",
                        fontWeight: "bold",
                        fontSize: "0.9rem",
                        cursor: "pointer",
                        transition: "all 0.3s ease",
                        boxShadow: "0 4px 15px rgba(168, 137, 255, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2)",
                        position: "relative",
                        overflow: "hidden",
                        opacity: isLoading ? 0.7 : 1,
                        backdropFilter: "blur(10px)"
                    },
                    className: "jsx-d84d40bda5631ea0" + " " + 'members-area-badge',
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                position: "absolute",
                                top: "-2px",
                                left: "-2px",
                                right: "-2px",
                                bottom: "-2px",
                                background: "linear-gradient(45deg, #a889ff, #fff, #a889ff)",
                                borderRadius: "27px",
                                zIndex: -1,
                                opacity: 0.3,
                                animation: "border-pulse 3s ease-in-out infinite"
                            },
                            className: "jsx-d84d40bda5631ea0"
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/Footer.tsx",
                            lineNumber: 56,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                position: "absolute",
                                top: 0,
                                left: "-100%",
                                width: "100%",
                                height: "100%",
                                background: "linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)",
                                transition: "left 0.5s ease"
                            },
                            className: "jsx-d84d40bda5631ea0" + " " + 'shimmer-effect'
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/Footer.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                position: "relative",
                                zIndex: 1
                            },
                            className: "jsx-d84d40bda5631ea0",
                            children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "jsx-d84d40bda5631ea0" + " " + 'flex items-center justify-center',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        className: "jsx-d84d40bda5631ea0" + " " + 'animate-spin -ml-1 mr-2 h-4 w-4 text-black',
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                cx: "12",
                                                cy: "12",
                                                r: "10",
                                                stroke: "currentColor",
                                                strokeWidth: "4",
                                                className: "jsx-d84d40bda5631ea0" + " " + 'opacity-25'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/Footer.tsx",
                                                lineNumber: 94,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                fill: "currentColor",
                                                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z",
                                                className: "jsx-d84d40bda5631ea0" + " " + 'opacity-75'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/layout/Footer.tsx",
                                                lineNumber: 101,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/layout/Footer.tsx",
                                        lineNumber: 89,
                                        columnNumber: 19
                                    }, this),
                                    "Opening portal..."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/layout/Footer.tsx",
                                lineNumber: 88,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: "✨ Members Area ✨"
                            }, void 0, false)
                        }, void 0, false, {
                            fileName: "[project]/src/components/layout/Footer.tsx",
                            lineNumber: 86,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/layout/Footer.tsx",
                    lineNumber: 32,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/layout/Footer.tsx",
                lineNumber: 31,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "d84d40bda5631ea0",
                children: ".members-area-badge.jsx-d84d40bda5631ea0:hover{animation:none;transform:translateY(-2px)scale(1.05);box-shadow:0 8px 25px #a889ff99,0 0 0 1px #ffffff4d}.members-area-badge.jsx-d84d40bda5631ea0:hover .shimmer-effect.jsx-d84d40bda5631ea0{left:100%}.members-area-badge.jsx-d84d40bda5631ea0:active{transform:translateY(0)scale(1.02)}@keyframes gradient-shift{0%,to{background-position:0%}50%{background-position:100%}}@keyframes border-pulse{0%,to{opacity:.3}50%{opacity:.6}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layout/Footer.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Footer;
}}),
"[project]/src/lib/stripe/StripeContext.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "StripeProvider": (()=>StripeProvider),
    "useStripe": (()=>useStripe)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$lib$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@stripe/stripe-js/lib/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@stripe/stripe-js/dist/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
const StripeContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])({
    stripe: null,
    loading: true,
    error: null
});
const useStripe = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(StripeContext);
    if (!context) {
        throw new Error("useStripe must be used within a StripeProvider");
    }
    return context;
};
const StripeProvider = ({ children, publishableKey })=>{
    const [stripe, setStripe] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const initializeStripe = async ()=>{
            try {
                setLoading(true);
                const stripeInstance = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadStripe"])(publishableKey);
                setStripe(stripeInstance);
            } catch (err) {
                setError(err instanceof Error ? err.message : "Failed to load Stripe");
            } finally{
                setLoading(false);
            }
        };
        if (publishableKey) {
            initializeStripe();
        } else {
            setError("Stripe publishable key is required");
            setLoading(false);
        }
    }, [
        publishableKey
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StripeContext.Provider, {
        value: {
            stripe,
            loading,
            error
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/stripe/StripeContext.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
};
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/contexts/TikTokPixelProvider.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "TikTokPixelProvider": (()=>TikTokPixelProvider),
    "useTikTok": (()=>useTikTok)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const TikTokPixelContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
const TikTokPixelProvider = ({ children, pixelId })=>{
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const trackEvent = (eventName, parameters)=>{
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    };
    const trackPurchase = (value, currency = "USD", contentId)=>{
        trackEvent("Purchase", {
            value: value,
            currency: currency,
            content_id: contentId,
            content_type: "product"
        });
    };
    const trackAddToCart = (value, currency = "USD", contentId)=>{
        trackEvent("AddToCart", {
            value: value,
            currency: currency,
            content_id: contentId,
            content_type: "product"
        });
    };
    const trackViewContent = (value, currency = "USD", contentId)=>{
        trackEvent("ViewContent", {
            value: value,
            currency: currency,
            content_id: contentId,
            content_type: "product"
        });
    };
    const trackInitiateCheckout = (value, currency = "USD", contentId)=>{
        trackEvent("InitiateCheckout", {
            value: value,
            currency: currency,
            content_id: contentId,
            content_type: "product"
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    }, [
        pathname
    ]);
    const contextValue = {
        trackEvent,
        trackPurchase,
        trackAddToCart,
        trackViewContent,
        trackInitiateCheckout
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TikTokPixelContext.Provider, {
        value: contextValue,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "tiktok-pixel",
                strategy: "afterInteractive",
                children: `
          !function (w, d, t) {
              w.TiktokAnalyticsObject = t;
              var ttq = w[t] = w[t] || [];
              ttq.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie"];
              ttq.setAndDefer = function (t, e) {
                  t[e] = function () {
                      t.push([e].concat(Array.prototype.slice.call(arguments, 0)))
                  }
              };
              for (var i = 0; i < ttq.methods.length; i++) {
                  ttq.setAndDefer(ttq, ttq.methods[i])
              }
              ttq.load = function (e, n) {
                  var i = "https://analytics.tiktok.com/i18n/pixel/events.js";
                  ttq._i = ttq._i || {};
                  ttq._i[e] = [];
                  ttq._i[e]._u = i;
                  ttq._t = ttq._t || {};
                  ttq._t[e] = +new Date;
                  ttq._o = ttq._o || {};
                  ttq._o[e] = n || {};
                  var a = document.createElement("script");
                  a.type = "text/javascript";
                  a.async = true;
                  a.src = i + "?sdkid=" + e + "&lib=" + t;
                  var s = document.getElementsByTagName("script")[0];
                  s.parentNode.insertBefore(a, s);
              };
              ttq.load('${pixelId}');
              ttq.page();
          }(window, document, 'ttq');
        `
            }, void 0, false, {
                fileName: "[project]/src/contexts/TikTokPixelProvider.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/src/contexts/TikTokPixelProvider.tsx",
        lineNumber: 123,
        columnNumber: 5
    }, this);
};
const useTikTok = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(TikTokPixelContext);
    if (!context) {
        throw new Error("useTikTok must be used within a TikTokPixelProvider");
    }
    return context;
};
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__6ef754c5._.js.map