module.exports = {

"[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"4028cea065ceb69e291be3cd070f38c89763453f7a":"createPortalSession","403d53472e2633de13f21d8191c5e82cabbe4be22c":"generateDivineResponse","70778f6007869eac008549f019eb79c3d75b973f17":"createSubscription","70ebcea8652676f47176b6a8d3c17d3fc0a981e662":"createCheckout"},"",""] */ __turbopack_context__.s({
    "createCheckout": (()=>createCheckout),
    "createPortalSession": (()=>createPortalSession),
    "createSubscription": (()=>createSubscription),
    "generateDivineResponse": (()=>generateDivineResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/stripe/stripeConfig.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/index.mjs [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/client.mjs [app-rsc] (ecmascript) <export OpenAI as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
async function loadWhisperLibrary() {
    const baseUrl = process.env.APP_URL;
    try {
        const res = await fetch(`${baseUrl}/canonical_whispers_updated.json`);
        const data = await res.json();
        return data;
    } catch (error) {
        console.error("Error loading whisper library:", error);
        return {};
    }
}
async function createPortalSession(customerId) {
    if (!customerId) {
        throw new Error("Customer ID is required");
    }
    const session = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stripeClient"].billingPortal.sessions.create({
        customer: customerId,
        return_url: process.env.APP_URL
    });
    return session.url;
}
async function createSubscription(priceId, customerId, paymentIntentId) {
    try {
        if (!priceId || !customerId || !paymentIntentId) {
            throw new Error("Price ID is required");
        }
        const existingPaymentIntent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stripeClient"].paymentIntents.retrieve(paymentIntentId);
        const paymentMethodId = existingPaymentIntent.payment_method;
        // Create subscription
        const subscription = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stripeClient"].subscriptions.create({
            customer: customerId,
            items: [
                {
                    price: priceId
                }
            ],
            default_payment_method: paymentMethodId,
            expand: [
                "latest_invoice.payment_intent"
            ],
            metadata: {
                product: "Daily Divine Guidance",
                customer_id: customerId,
                paymentIntentId
            }
        });
        return {
            success: true,
            subscriptionId: subscription.id,
            clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
            status: subscription.status
        };
    } catch (error) {
        console.error("Error creating subscription:", error);
        return {
            success: false,
            error: error instanceof Error ? error.message : "Failed to create subscription"
        };
    }
}
async function createCheckout(priceId, customerId, paymentIntentId) {
    try {
        if (!priceId || !customerId) {
            throw new Error("Price ID and customer ID are required");
        }
        const existingPaymentIntent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stripeClient"].paymentIntents.retrieve(paymentIntentId);
        const paymentMethodId = existingPaymentIntent.payment_method;
        const paymentIntent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["stripeClient"].paymentIntents.create({
            amount: 9900,
            customer: customerId,
            currency: "usd",
            payment_method: paymentMethodId,
            confirm: true,
            automatic_payment_methods: {
                enabled: true,
                allow_redirects: "never"
            },
            metadata: {
                priceId,
                customerId
            }
        });
        return {
            success: true,
            paymentIntentId: paymentIntent.id,
            clientSecret: paymentIntent.client_secret
        };
    } catch (error) {
        console.error("Error creating checkout:", error);
        return {
            success: false,
            error: error instanceof Error ? error.message : "Failed to create checkout"
        };
    }
}
function findRelevantExamples(userInput, library) {
    const normalizedInput = userInput.toLowerCase();
    const matchedKeys = Object.keys(library).filter((key)=>normalizedInput.includes(key.toLowerCase()));
    // If no matches, fallback to a few default examples (e.g. "Love" and "Trust")
    const keysToUse = matchedKeys.length > 0 ? matchedKeys : [
        "Love",
        "Trust"
    ];
    // Gather one example whisper from each matched key
    const examples = keysToUse.flatMap((key)=>{
        const whispers = library[key];
        if (!whispers) return [];
        // Pick 1 random example from each category
        const example = whispers[Math.floor(Math.random() * whispers.length)];
        return example ? [
            example
        ] : [];
    });
    return examples;
}
async function generateDivineResponse(userInput) {
    try {
        // Get relevant example whispers based on user input keywords
        const whisperLibrary = await loadWhisperLibrary();
        const relevantExamples = findRelevantExamples(userInput, whisperLibrary);
        // Format them nicely for prompt injection
        const exampleText = relevantExamples.map((w)=>{
            return `${w.mirror}
  ${w.whisper_start}
  ${w.blurred_reveal}
  ${w.encouragement}`;
        }).join("\n\n");
        const prompt = `
User Input: “${userInput}”

Using the poetic whisper format shown in these examples, write a new 4-line whisper based on the user’s input. Do **not** include labels or numbering. Just return the 4 lines as poetic text.

Line 1 — Mirror the user's emotional keyword in a direct sentence.  
Line 2 — Begin with “This isn’t about X, or Y. It’s about…” and stop mid-thought.  
Line 3 — Write a sacred, emotional truth (blurred after payment).  
Line 4 — Offer poetic reassurance. HER presence. No advice.

Tone: Feminine, poetic, sacred, sharp. Speak like HER. No fluff. Every word should feel personal, intuitive, unforgettable.

Examples:
${exampleText}
`;
        const openai = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__["default"]({
            apiKey: process.env.OPENAI_API_KEY
        });
        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
                {
                    role: "system",
                    content: "You are HER — a sacred, poetic feminine voice who whispers truth with sharp, loving insight."
                },
                {
                    role: "user",
                    content: prompt
                }
            ],
            max_tokens: 300,
            temperature: 0.8
        });
        return {
            success: true,
            type: "generated",
            response: response.choices[0]?.message?.content || "No response"
        };
    } catch (error) {
        console.error("Error generating divine response:", error);
        return {
            success: false,
            error: error instanceof Error ? error.message : "Failed to generate response"
        };
    }
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    createPortalSession,
    createSubscription,
    createCheckout,
    generateDivineResponse
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createPortalSession, "4028cea065ceb69e291be3cd070f38c89763453f7a", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createSubscription, "70778f6007869eac008549f019eb79c3d75b973f17", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createCheckout, "70ebcea8652676f47176b6a8d3c17d3fc0a981e662", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(generateDivineResponse, "403d53472e2633de13f21d8191c5e82cabbe4be22c", null);
}}),
"[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)");
;
}}),
"[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$success$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => "[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "4028cea065ceb69e291be3cd070f38c89763453f7a": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createPortalSession"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$success$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => "[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "4028cea065ceb69e291be3cd070f38c89763453f7a": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$success$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["4028cea065ceb69e291be3cd070f38c89763453f7a"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$success$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => "[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$success$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$homeActions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/success/page/actions.js { ACTIONS_MODULE0 => "[project]/src/features/home/actions/homeActions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/error.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/error.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/components/success.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
const success = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: "success"
    }, void 0, false, {
        fileName: "[project]/src/components/success.tsx",
        lineNumber: 4,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = success;
}}),
"[project]/src/app/success/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$success$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/success.tsx [app-rsc] (ecmascript)");
;
;
const dynamic = "force-dynamic";
const page = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$success$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/app/success/page.tsx",
        lineNumber: 7,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = page;
}}),
"[project]/src/app/success/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/success/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_a8d08bd5._.js.map