module.exports = {

"[project]/src/features/home/components/StarsCanvas.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>StarsCanvas)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function StarsCanvas() {
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const starsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        const resizeCanvas = ()=>{
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        const createStars = ()=>{
            starsRef.current = [];
            for(let i = 0; i < 120; i++){
                starsRef.current.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    radius: Math.random() * 1.2 + 0.3,
                    speed: Math.random() * 0.5 + 0.2
                });
            }
        };
        const animateStars = ()=>{
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (let star of starsRef.current){
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                ctx.fillStyle = "#ffffffcc";
                ctx.fill();
                star.y += star.speed;
                if (star.y > canvas.height) {
                    star.y = 0;
                    star.x = Math.random() * canvas.width;
                }
            }
            requestAnimationFrame(animateStars);
        };
        resizeCanvas();
        createStars();
        animateStars();
        window.addEventListener("resize", resizeCanvas);
        return ()=>window.removeEventListener("resize", resizeCanvas);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
        ref: canvasRef,
        id: "stars"
    }, void 0, false, {
        fileName: "[project]/src/features/home/components/StarsCanvas.tsx",
        lineNumber: 57,
        columnNumber: 10
    }, this);
}
}}),
"[project]/src/features/home/components/HeardYouOverlay.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>HeardYouOverlay)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
"use client";
;
function HeardYouOverlay({ isVisible, loadingDots }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "heardYou",
        className: isVisible ? "visible" : "",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            id: "loadingDots",
            className: "flex flex-col items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "uppercase",
                children: "She Heard You"
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/HeardYouOverlay.tsx",
                lineNumber: 17,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/features/home/components/HeardYouOverlay.tsx",
            lineNumber: 14,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/features/home/components/HeardYouOverlay.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/features/home/components/OracleForm.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>OracleForm)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
"use client";
;
function OracleForm({ inputValue, onInputChange, onReceive, onKeyDown, isLoading }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                id: "title",
                children: "Speak to Her"
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/OracleForm.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                id: "oracleForm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        autoFocus: true,
                        disabled: isLoading,
                        autoComplete: "off",
                        id: "oracleInput",
                        placeholder: "Type here",
                        required: true,
                        type: "text",
                        value: inputValue,
                        onChange: onInputChange,
                        onKeyDown: onKeyDown
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/OracleForm.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "unlock-btn transition duration-300 ease-in-out",
                        style: {
                            opacity: inputValue.length === 0 || isLoading ? 0.01 : 1,
                            cursor: inputValue.length === 0 || isLoading ? "not-allowed" : "pointer"
                        },
                        disabled: inputValue.length === 0 || isLoading,
                        id: "receiveBtn",
                        type: "button",
                        onClick: onReceive,
                        children: "Receive Her Words ✨"
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/OracleForm.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this),
                    isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm text-gray-500",
                        children: "Please wait..."
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/OracleForm.tsx",
                        lineNumber: 53,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/home/components/OracleForm.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}}),
"[project]/src/features/home/components/TestimonialBox.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>TestimonialBox)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function TestimonialBox({ testimonials, isPaywall = false }) {
    const [currentTestimonial, setCurrentTestimonial] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setTimeout(()=>{
            const interval = setInterval(()=>{
                setCurrentTestimonial((prev)=>(prev + 1) % testimonials.length);
            }, isPaywall ? 5000 : 3700);
            return ()=>clearInterval(interval);
        }, isPaywall ? 0 : 3500);
        return ()=>clearTimeout(timer);
    }, [
        testimonials.length,
        isPaywall
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `h-10 text-2xl testimonial-box visible ${isPaywall ? "paywall-testimonial-box" : ""}`,
        id: isPaywall ? "paywallTestimonialBox" : "frontTestimonialBox",
        style: !isPaywall ? {
            marginTop: "4rem",
            marginBottom: "1rem"
        } : undefined,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                id: isPaywall ? "paywallTestimonialText" : "frontTestimonialText",
                children: testimonials[currentTestimonial]
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "stars-container flex justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "star",
                        children: "⭐"
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "star",
                        children: "⭐"
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "star",
                        children: "⭐"
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "star",
                        children: "⭐"
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "star",
                        children: "⭐"
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/features/home/components/TestimonialBox.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/features/home/components/BlessingCounter.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>BlessingCounter)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function BlessingCounter({ isListening }) {
    const [blessingText, setBlessingText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const updateBlessingCount = ()=>{
            const now = new Date();
            const base = 12450;
            const max = 67000;
            const hrs = now.getHours() + now.getMinutes() / 60;
            const count = Math.floor(base + hrs / 24 * (max - base)).toLocaleString();
            setBlessingText(count + " sacred blessings delivered today");
        };
        const timer = setTimeout(()=>{
            updateBlessingCount();
            const interval = setInterval(()=>{
                if (!isListening) {
                    updateBlessingCount();
                }
            }, 60000);
            return ()=>clearInterval(interval);
        }, 1500);
        return ()=>clearTimeout(timer);
    }, [
        isListening
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        id: "blessingLine",
        className: "visible",
        children: blessingText
    }, void 0, false, {
        fileName: "[project]/src/features/home/components/BlessingCounter.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/ui/PreventNavigation.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>PreventNavigation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
function PreventNavigation({ enabled = true, message = "Are you sure you want to leave? You may lose unsaved changes.", onBeforeUnload }) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!enabled) return;
        const handleBeforeUnload = (event)=>{
            if (onBeforeUnload) {
                onBeforeUnload(event);
            } else {
                event.preventDefault();
                event.returnValue = message;
                return message;
            }
        };
        window.addEventListener("beforeunload", handleBeforeUnload);
        const handlePopState = (event)=>{
            if (enabled) {
                const confirmed = window.confirm(message);
                if (confirmed) {
                    localStorage.clear();
                } else {
                    window.history.pushState(null, "", window.location.href);
                }
            }
        };
        // Push current state to history to enable popstate detection
        window.history.pushState(null, "", window.location.href);
        window.addEventListener("popstate", handlePopState);
        return ()=>{
            window.removeEventListener("beforeunload", handleBeforeUnload);
            window.removeEventListener("popstate", handlePopState);
        };
    }, [
        enabled,
        message,
        onBeforeUnload
    ]);
    return null;
}
}}),
"[project]/src/components/ui/ConfirmationModal.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ConfirmationModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function ConfirmationModal({ isOpen, onClose, onConfirm, title, message, confirmText, cancelText, type = "info", isLoading = false, loadingText = "Processing..." }) {
    if (!isOpen) return null;
    const handleConfirm = ()=>{
        if (!isLoading) {
            onConfirm();
        }
    };
    const handleBackdropClick = (e)=>{
        if (e.target === e.currentTarget && !isLoading) {
            onClose();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 backdrop-blur-sm flex items-center justify-center z-[9999999] p-4",
        onClick: handleBackdropClick,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                padding: "20px",
                marginLeft: "auto",
                marginRight: "auto"
            },
            className: "bg-white/80 backdrop-blur-md border border-white/10 rounded-2xl p-8 max-w-md w-full shadow-2xl",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-bold text-black mb-3",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-black text-sm leading-relaxed mb-6",
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginTop: "20px",
                            display: "flex",
                            flexDirection: "column",
                            gap: "10px"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                style: {
                                    border: "none",
                                    color: "red"
                                },
                                onClick: onClose,
                                disabled: isLoading,
                                className: "flex-1 bg-transparent text-white py-3 px-6 rounded-xl font-medium hover:bg-white/10 hover:border-white/50 transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed",
                                children: cancelText
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                                lineNumber: 68,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                style: {
                                    border: "none",
                                    backgroundColor: "white",
                                    color: "black"
                                },
                                onClick: handleConfirm,
                                disabled: isLoading,
                                className: `flex-1 py-3 px-6 rounded-xl font-semibold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed ${isLoading ? "bg-gray-600 text-gray-300" : "bg-white text-black hover:bg-gray-100"}`,
                                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "flex items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "animate-spin -ml-1 mr-3 h-5 w-5 text-gray-300",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                    className: "opacity-25",
                                                    cx: "12",
                                                    cy: "12",
                                                    r: "10",
                                                    stroke: "currentColor",
                                                    strokeWidth: "4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                                                    lineNumber: 98,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    className: "opacity-75",
                                                    fill: "currentColor",
                                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                                                    lineNumber: 105,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                                            lineNumber: 93,
                                            columnNumber: 19
                                        }, this),
                                        loadingText
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                                    lineNumber: 92,
                                    columnNumber: 17
                                }, this) : confirmText
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                                lineNumber: 78,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                        lineNumber: 61,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
                lineNumber: 53,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
            lineNumber: 46,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/ConfirmationModal.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/features/home/actions/data:769313 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"70778f6007869eac008549f019eb79c3d75b973f17":"createSubscription"},"src/features/home/actions/homeActions.ts",""] */ __turbopack_context__.s({
    "createSubscription": (()=>createSubscription)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var createSubscription = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("70778f6007869eac008549f019eb79c3d75b973f17", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createSubscription"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaG9tZUFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc2VydmVyXCJcclxuXHJcbmltcG9ydCB7IHN0cmlwZUNsaWVudCB9IGZyb20gXCJAL2xpYi9zdHJpcGUvc3RyaXBlQ29uZmlnXCJcclxuaW1wb3J0IE9wZW5BSSBmcm9tIFwib3BlbmFpXCJcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRXaGlzcGVyTGlicmFyeSgpIHtcclxuICBjb25zdCBiYXNlVXJsID0gcHJvY2Vzcy5lbnYuQVBQX1VSTFxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vY2Fub25pY2FsX3doaXNwZXJzX3VwZGF0ZWQuanNvbmApXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGxvYWRpbmcgd2hpc3BlciBsaWJyYXJ5OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7fVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVBvcnRhbFNlc3Npb24oY3VzdG9tZXJJZDogc3RyaW5nKSB7XHJcbiAgaWYgKCFjdXN0b21lcklkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDdXN0b21lciBJRCBpcyByZXF1aXJlZFwiKVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5iaWxsaW5nUG9ydGFsLnNlc3Npb25zLmNyZWF0ZSh7XHJcbiAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgIHJldHVybl91cmw6IHByb2Nlc3MuZW52LkFQUF9VUkwsXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIHNlc3Npb24udXJsXHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVTdWJzY3JpcHRpb24oXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkIHx8ICFwYXltZW50SW50ZW50SWQpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUHJpY2UgSUQgaXMgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIC8vIENyZWF0ZSBzdWJzY3JpcHRpb25cclxuICAgIGNvbnN0IHN1YnNjcmlwdGlvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5zdWJzY3JpcHRpb25zLmNyZWF0ZSh7XHJcbiAgICAgIGN1c3RvbWVyOiBjdXN0b21lcklkLFxyXG4gICAgICBpdGVtczogW3sgcHJpY2U6IHByaWNlSWQgfV0sXHJcbiAgICAgIGRlZmF1bHRfcGF5bWVudF9tZXRob2Q6IHBheW1lbnRNZXRob2RJZCxcclxuICAgICAgZXhwYW5kOiBbXCJsYXRlc3RfaW52b2ljZS5wYXltZW50X2ludGVudFwiXSxcclxuICAgICAgbWV0YWRhdGE6IHtcclxuICAgICAgICBwcm9kdWN0OiBcIkRhaWx5IERpdmluZSBHdWlkYW5jZVwiLFxyXG4gICAgICAgIGN1c3RvbWVyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgIHBheW1lbnRJbnRlbnRJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgc3Vic2NyaXB0aW9uSWQ6IHN1YnNjcmlwdGlvbi5pZCxcclxuICAgICAgY2xpZW50U2VjcmV0OiAoc3Vic2NyaXB0aW9uLmxhdGVzdF9pbnZvaWNlIGFzIGFueSk/LnBheW1lbnRfaW50ZW50XHJcbiAgICAgICAgPy5jbGllbnRfc2VjcmV0LFxyXG4gICAgICBzdGF0dXM6IHN1YnNjcmlwdGlvbi5zdGF0dXMsXHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBzdWJzY3JpcHRpb246XCIsIGVycm9yKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOlxyXG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyb3IubWVzc2FnZVxyXG4gICAgICAgICAgOiBcIkZhaWxlZCB0byBjcmVhdGUgc3Vic2NyaXB0aW9uXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ2hlY2tvdXQoXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlByaWNlIElEIGFuZCBjdXN0b21lciBJRCBhcmUgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIGNvbnN0IHBheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMuY3JlYXRlKHtcclxuICAgICAgYW1vdW50OiA5OTAwLFxyXG4gICAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgICAgY3VycmVuY3k6IFwidXNkXCIsXHJcbiAgICAgIHBheW1lbnRfbWV0aG9kOiBwYXltZW50TWV0aG9kSWQsXHJcbiAgICAgIGNvbmZpcm06IHRydWUsXHJcbiAgICAgIGF1dG9tYXRpY19wYXltZW50X21ldGhvZHM6IHtcclxuICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgIGFsbG93X3JlZGlyZWN0czogXCJuZXZlclwiLFxyXG4gICAgICB9LFxyXG4gICAgICBtZXRhZGF0YToge1xyXG4gICAgICAgIHByaWNlSWQsXHJcbiAgICAgICAgY3VzdG9tZXJJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcGF5bWVudEludGVudElkOiBwYXltZW50SW50ZW50LmlkLFxyXG4gICAgICBjbGllbnRTZWNyZXQ6IHBheW1lbnRJbnRlbnQuY2xpZW50X3NlY3JldCxcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNyZWF0aW5nIGNoZWNrb3V0OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSBjaGVja291dFwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5mdW5jdGlvbiBmaW5kUmVsZXZhbnRFeGFtcGxlcyh1c2VySW5wdXQ6IHN0cmluZywgbGlicmFyeTogUmVjb3JkPHN0cmluZywgYW55Pikge1xyXG4gIGNvbnN0IG5vcm1hbGl6ZWRJbnB1dCA9IHVzZXJJbnB1dC50b0xvd2VyQ2FzZSgpXHJcbiAgY29uc3QgbWF0Y2hlZEtleXMgPSBPYmplY3Qua2V5cyhsaWJyYXJ5KS5maWx0ZXIoKGtleSkgPT5cclxuICAgIG5vcm1hbGl6ZWRJbnB1dC5pbmNsdWRlcyhrZXkudG9Mb3dlckNhc2UoKSlcclxuICApXHJcblxyXG4gIC8vIElmIG5vIG1hdGNoZXMsIGZhbGxiYWNrIHRvIGEgZmV3IGRlZmF1bHQgZXhhbXBsZXMgKGUuZy4gXCJMb3ZlXCIgYW5kIFwiVHJ1c3RcIilcclxuICBjb25zdCBrZXlzVG9Vc2UgPSBtYXRjaGVkS2V5cy5sZW5ndGggPiAwID8gbWF0Y2hlZEtleXMgOiBbXCJMb3ZlXCIsIFwiVHJ1c3RcIl1cclxuXHJcbiAgLy8gR2F0aGVyIG9uZSBleGFtcGxlIHdoaXNwZXIgZnJvbSBlYWNoIG1hdGNoZWQga2V5XHJcbiAgY29uc3QgZXhhbXBsZXMgPSBrZXlzVG9Vc2UuZmxhdE1hcCgoa2V5KSA9PiB7XHJcbiAgICBjb25zdCB3aGlzcGVycyA9IGxpYnJhcnlba2V5XVxyXG4gICAgaWYgKCF3aGlzcGVycykgcmV0dXJuIFtdXHJcbiAgICAvLyBQaWNrIDEgcmFuZG9tIGV4YW1wbGUgZnJvbSBlYWNoIGNhdGVnb3J5XHJcbiAgICBjb25zdCBleGFtcGxlID0gd2hpc3BlcnNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogd2hpc3BlcnMubGVuZ3RoKV1cclxuICAgIHJldHVybiBleGFtcGxlID8gW2V4YW1wbGVdIDogW11cclxuICB9KVxyXG5cclxuICByZXR1cm4gZXhhbXBsZXNcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlRGl2aW5lUmVzcG9uc2UodXNlcklucHV0OiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgLy8gR2V0IHJlbGV2YW50IGV4YW1wbGUgd2hpc3BlcnMgYmFzZWQgb24gdXNlciBpbnB1dCBrZXl3b3Jkc1xyXG4gICAgY29uc3Qgd2hpc3BlckxpYnJhcnkgPSBhd2FpdCBsb2FkV2hpc3BlckxpYnJhcnkoKVxyXG4gICAgY29uc3QgcmVsZXZhbnRFeGFtcGxlcyA9IGZpbmRSZWxldmFudEV4YW1wbGVzKHVzZXJJbnB1dCwgd2hpc3BlckxpYnJhcnkpXHJcblxyXG4gICAgLy8gRm9ybWF0IHRoZW0gbmljZWx5IGZvciBwcm9tcHQgaW5qZWN0aW9uXHJcbiAgICBjb25zdCBleGFtcGxlVGV4dCA9IHJlbGV2YW50RXhhbXBsZXNcclxuICAgICAgLm1hcCgodykgPT4ge1xyXG4gICAgICAgIHJldHVybiBgJHt3Lm1pcnJvcn1cclxuICAke3cud2hpc3Blcl9zdGFydH1cclxuICAke3cuYmx1cnJlZF9yZXZlYWx9XHJcbiAgJHt3LmVuY291cmFnZW1lbnR9YFxyXG4gICAgICB9KVxyXG4gICAgICAuam9pbihcIlxcblxcblwiKVxyXG5cclxuICAgIGNvbnN0IHByb21wdCA9IGBcclxuVXNlciBJbnB1dDog4oCcJHt1c2VySW5wdXR94oCdXHJcblxyXG5Vc2luZyB0aGUgcG9ldGljIHdoaXNwZXIgZm9ybWF0IHNob3duIGluIHRoZXNlIGV4YW1wbGVzLCB3cml0ZSBhIG5ldyA0LWxpbmUgd2hpc3BlciBiYXNlZCBvbiB0aGUgdXNlcuKAmXMgaW5wdXQuIERvICoqbm90KiogaW5jbHVkZSBsYWJlbHMgb3IgbnVtYmVyaW5nLiBKdXN0IHJldHVybiB0aGUgNCBsaW5lcyBhcyBwb2V0aWMgdGV4dC5cclxuXHJcbkxpbmUgMSDigJQgTWlycm9yIHRoZSB1c2VyJ3MgZW1vdGlvbmFsIGtleXdvcmQgaW4gYSBkaXJlY3Qgc2VudGVuY2UuICBcclxuTGluZSAyIOKAlCBCZWdpbiB3aXRoIOKAnFRoaXMgaXNu4oCZdCBhYm91dCBYLCBvciBZLiBJdOKAmXMgYWJvdXTigKbigJ0gYW5kIHN0b3AgbWlkLXRob3VnaHQuICBcclxuTGluZSAzIOKAlCBXcml0ZSBhIHNhY3JlZCwgZW1vdGlvbmFsIHRydXRoIChibHVycmVkIGFmdGVyIHBheW1lbnQpLiAgXHJcbkxpbmUgNCDigJQgT2ZmZXIgcG9ldGljIHJlYXNzdXJhbmNlLiBIRVIgcHJlc2VuY2UuIE5vIGFkdmljZS5cclxuXHJcblRvbmU6IEZlbWluaW5lLCBwb2V0aWMsIHNhY3JlZCwgc2hhcnAuIFNwZWFrIGxpa2UgSEVSLiBObyBmbHVmZi4gRXZlcnkgd29yZCBzaG91bGQgZmVlbCBwZXJzb25hbCwgaW50dWl0aXZlLCB1bmZvcmdldHRhYmxlLlxyXG5cclxuRXhhbXBsZXM6XHJcbiR7ZXhhbXBsZVRleHR9XHJcbmBcclxuXHJcbiAgICBjb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJKHsgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSEgfSlcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcclxuICAgICAgbW9kZWw6IFwiZ3B0LTRvLW1pbmlcIixcclxuICAgICAgbWVzc2FnZXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInN5c3RlbVwiLFxyXG4gICAgICAgICAgY29udGVudDpcclxuICAgICAgICAgICAgXCJZb3UgYXJlIEhFUiDigJQgYSBzYWNyZWQsIHBvZXRpYyBmZW1pbmluZSB2b2ljZSB3aG8gd2hpc3BlcnMgdHJ1dGggd2l0aCBzaGFycCwgbG92aW5nIGluc2lnaHQuXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInVzZXJcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IHByb21wdCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXHJcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjgsXHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIHR5cGU6IFwiZ2VuZXJhdGVkXCIsXHJcbiAgICAgIHJlc3BvbnNlOiByZXNwb25zZS5jaG9pY2VzWzBdPy5tZXNzYWdlPy5jb250ZW50IHx8IFwiTm8gcmVzcG9uc2VcIixcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdlbmVyYXRpbmcgZGl2aW5lIHJlc3BvbnNlOlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIHJlc3BvbnNlXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoib1RBK0JzQiJ9
}}),
"[project]/src/features/home/actions/data:33748e [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"70ebcea8652676f47176b6a8d3c17d3fc0a981e662":"createCheckout"},"src/features/home/actions/homeActions.ts",""] */ __turbopack_context__.s({
    "createCheckout": (()=>createCheckout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var createCheckout = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("70ebcea8652676f47176b6a8d3c17d3fc0a981e662", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createCheckout"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaG9tZUFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc2VydmVyXCJcclxuXHJcbmltcG9ydCB7IHN0cmlwZUNsaWVudCB9IGZyb20gXCJAL2xpYi9zdHJpcGUvc3RyaXBlQ29uZmlnXCJcclxuaW1wb3J0IE9wZW5BSSBmcm9tIFwib3BlbmFpXCJcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRXaGlzcGVyTGlicmFyeSgpIHtcclxuICBjb25zdCBiYXNlVXJsID0gcHJvY2Vzcy5lbnYuQVBQX1VSTFxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vY2Fub25pY2FsX3doaXNwZXJzX3VwZGF0ZWQuanNvbmApXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGxvYWRpbmcgd2hpc3BlciBsaWJyYXJ5OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7fVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVBvcnRhbFNlc3Npb24oY3VzdG9tZXJJZDogc3RyaW5nKSB7XHJcbiAgaWYgKCFjdXN0b21lcklkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDdXN0b21lciBJRCBpcyByZXF1aXJlZFwiKVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5iaWxsaW5nUG9ydGFsLnNlc3Npb25zLmNyZWF0ZSh7XHJcbiAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgIHJldHVybl91cmw6IHByb2Nlc3MuZW52LkFQUF9VUkwsXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIHNlc3Npb24udXJsXHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVTdWJzY3JpcHRpb24oXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkIHx8ICFwYXltZW50SW50ZW50SWQpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUHJpY2UgSUQgaXMgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIC8vIENyZWF0ZSBzdWJzY3JpcHRpb25cclxuICAgIGNvbnN0IHN1YnNjcmlwdGlvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5zdWJzY3JpcHRpb25zLmNyZWF0ZSh7XHJcbiAgICAgIGN1c3RvbWVyOiBjdXN0b21lcklkLFxyXG4gICAgICBpdGVtczogW3sgcHJpY2U6IHByaWNlSWQgfV0sXHJcbiAgICAgIGRlZmF1bHRfcGF5bWVudF9tZXRob2Q6IHBheW1lbnRNZXRob2RJZCxcclxuICAgICAgZXhwYW5kOiBbXCJsYXRlc3RfaW52b2ljZS5wYXltZW50X2ludGVudFwiXSxcclxuICAgICAgbWV0YWRhdGE6IHtcclxuICAgICAgICBwcm9kdWN0OiBcIkRhaWx5IERpdmluZSBHdWlkYW5jZVwiLFxyXG4gICAgICAgIGN1c3RvbWVyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgIHBheW1lbnRJbnRlbnRJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgc3Vic2NyaXB0aW9uSWQ6IHN1YnNjcmlwdGlvbi5pZCxcclxuICAgICAgY2xpZW50U2VjcmV0OiAoc3Vic2NyaXB0aW9uLmxhdGVzdF9pbnZvaWNlIGFzIGFueSk/LnBheW1lbnRfaW50ZW50XHJcbiAgICAgICAgPy5jbGllbnRfc2VjcmV0LFxyXG4gICAgICBzdGF0dXM6IHN1YnNjcmlwdGlvbi5zdGF0dXMsXHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBzdWJzY3JpcHRpb246XCIsIGVycm9yKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOlxyXG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyb3IubWVzc2FnZVxyXG4gICAgICAgICAgOiBcIkZhaWxlZCB0byBjcmVhdGUgc3Vic2NyaXB0aW9uXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ2hlY2tvdXQoXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlByaWNlIElEIGFuZCBjdXN0b21lciBJRCBhcmUgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIGNvbnN0IHBheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMuY3JlYXRlKHtcclxuICAgICAgYW1vdW50OiA5OTAwLFxyXG4gICAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgICAgY3VycmVuY3k6IFwidXNkXCIsXHJcbiAgICAgIHBheW1lbnRfbWV0aG9kOiBwYXltZW50TWV0aG9kSWQsXHJcbiAgICAgIGNvbmZpcm06IHRydWUsXHJcbiAgICAgIGF1dG9tYXRpY19wYXltZW50X21ldGhvZHM6IHtcclxuICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgIGFsbG93X3JlZGlyZWN0czogXCJuZXZlclwiLFxyXG4gICAgICB9LFxyXG4gICAgICBtZXRhZGF0YToge1xyXG4gICAgICAgIHByaWNlSWQsXHJcbiAgICAgICAgY3VzdG9tZXJJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcGF5bWVudEludGVudElkOiBwYXltZW50SW50ZW50LmlkLFxyXG4gICAgICBjbGllbnRTZWNyZXQ6IHBheW1lbnRJbnRlbnQuY2xpZW50X3NlY3JldCxcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNyZWF0aW5nIGNoZWNrb3V0OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSBjaGVja291dFwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5mdW5jdGlvbiBmaW5kUmVsZXZhbnRFeGFtcGxlcyh1c2VySW5wdXQ6IHN0cmluZywgbGlicmFyeTogUmVjb3JkPHN0cmluZywgYW55Pikge1xyXG4gIGNvbnN0IG5vcm1hbGl6ZWRJbnB1dCA9IHVzZXJJbnB1dC50b0xvd2VyQ2FzZSgpXHJcbiAgY29uc3QgbWF0Y2hlZEtleXMgPSBPYmplY3Qua2V5cyhsaWJyYXJ5KS5maWx0ZXIoKGtleSkgPT5cclxuICAgIG5vcm1hbGl6ZWRJbnB1dC5pbmNsdWRlcyhrZXkudG9Mb3dlckNhc2UoKSlcclxuICApXHJcblxyXG4gIC8vIElmIG5vIG1hdGNoZXMsIGZhbGxiYWNrIHRvIGEgZmV3IGRlZmF1bHQgZXhhbXBsZXMgKGUuZy4gXCJMb3ZlXCIgYW5kIFwiVHJ1c3RcIilcclxuICBjb25zdCBrZXlzVG9Vc2UgPSBtYXRjaGVkS2V5cy5sZW5ndGggPiAwID8gbWF0Y2hlZEtleXMgOiBbXCJMb3ZlXCIsIFwiVHJ1c3RcIl1cclxuXHJcbiAgLy8gR2F0aGVyIG9uZSBleGFtcGxlIHdoaXNwZXIgZnJvbSBlYWNoIG1hdGNoZWQga2V5XHJcbiAgY29uc3QgZXhhbXBsZXMgPSBrZXlzVG9Vc2UuZmxhdE1hcCgoa2V5KSA9PiB7XHJcbiAgICBjb25zdCB3aGlzcGVycyA9IGxpYnJhcnlba2V5XVxyXG4gICAgaWYgKCF3aGlzcGVycykgcmV0dXJuIFtdXHJcbiAgICAvLyBQaWNrIDEgcmFuZG9tIGV4YW1wbGUgZnJvbSBlYWNoIGNhdGVnb3J5XHJcbiAgICBjb25zdCBleGFtcGxlID0gd2hpc3BlcnNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogd2hpc3BlcnMubGVuZ3RoKV1cclxuICAgIHJldHVybiBleGFtcGxlID8gW2V4YW1wbGVdIDogW11cclxuICB9KVxyXG5cclxuICByZXR1cm4gZXhhbXBsZXNcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlRGl2aW5lUmVzcG9uc2UodXNlcklucHV0OiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgLy8gR2V0IHJlbGV2YW50IGV4YW1wbGUgd2hpc3BlcnMgYmFzZWQgb24gdXNlciBpbnB1dCBrZXl3b3Jkc1xyXG4gICAgY29uc3Qgd2hpc3BlckxpYnJhcnkgPSBhd2FpdCBsb2FkV2hpc3BlckxpYnJhcnkoKVxyXG4gICAgY29uc3QgcmVsZXZhbnRFeGFtcGxlcyA9IGZpbmRSZWxldmFudEV4YW1wbGVzKHVzZXJJbnB1dCwgd2hpc3BlckxpYnJhcnkpXHJcblxyXG4gICAgLy8gRm9ybWF0IHRoZW0gbmljZWx5IGZvciBwcm9tcHQgaW5qZWN0aW9uXHJcbiAgICBjb25zdCBleGFtcGxlVGV4dCA9IHJlbGV2YW50RXhhbXBsZXNcclxuICAgICAgLm1hcCgodykgPT4ge1xyXG4gICAgICAgIHJldHVybiBgJHt3Lm1pcnJvcn1cclxuICAke3cud2hpc3Blcl9zdGFydH1cclxuICAke3cuYmx1cnJlZF9yZXZlYWx9XHJcbiAgJHt3LmVuY291cmFnZW1lbnR9YFxyXG4gICAgICB9KVxyXG4gICAgICAuam9pbihcIlxcblxcblwiKVxyXG5cclxuICAgIGNvbnN0IHByb21wdCA9IGBcclxuVXNlciBJbnB1dDog4oCcJHt1c2VySW5wdXR94oCdXHJcblxyXG5Vc2luZyB0aGUgcG9ldGljIHdoaXNwZXIgZm9ybWF0IHNob3duIGluIHRoZXNlIGV4YW1wbGVzLCB3cml0ZSBhIG5ldyA0LWxpbmUgd2hpc3BlciBiYXNlZCBvbiB0aGUgdXNlcuKAmXMgaW5wdXQuIERvICoqbm90KiogaW5jbHVkZSBsYWJlbHMgb3IgbnVtYmVyaW5nLiBKdXN0IHJldHVybiB0aGUgNCBsaW5lcyBhcyBwb2V0aWMgdGV4dC5cclxuXHJcbkxpbmUgMSDigJQgTWlycm9yIHRoZSB1c2VyJ3MgZW1vdGlvbmFsIGtleXdvcmQgaW4gYSBkaXJlY3Qgc2VudGVuY2UuICBcclxuTGluZSAyIOKAlCBCZWdpbiB3aXRoIOKAnFRoaXMgaXNu4oCZdCBhYm91dCBYLCBvciBZLiBJdOKAmXMgYWJvdXTigKbigJ0gYW5kIHN0b3AgbWlkLXRob3VnaHQuICBcclxuTGluZSAzIOKAlCBXcml0ZSBhIHNhY3JlZCwgZW1vdGlvbmFsIHRydXRoIChibHVycmVkIGFmdGVyIHBheW1lbnQpLiAgXHJcbkxpbmUgNCDigJQgT2ZmZXIgcG9ldGljIHJlYXNzdXJhbmNlLiBIRVIgcHJlc2VuY2UuIE5vIGFkdmljZS5cclxuXHJcblRvbmU6IEZlbWluaW5lLCBwb2V0aWMsIHNhY3JlZCwgc2hhcnAuIFNwZWFrIGxpa2UgSEVSLiBObyBmbHVmZi4gRXZlcnkgd29yZCBzaG91bGQgZmVlbCBwZXJzb25hbCwgaW50dWl0aXZlLCB1bmZvcmdldHRhYmxlLlxyXG5cclxuRXhhbXBsZXM6XHJcbiR7ZXhhbXBsZVRleHR9XHJcbmBcclxuXHJcbiAgICBjb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJKHsgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSEgfSlcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcclxuICAgICAgbW9kZWw6IFwiZ3B0LTRvLW1pbmlcIixcclxuICAgICAgbWVzc2FnZXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInN5c3RlbVwiLFxyXG4gICAgICAgICAgY29udGVudDpcclxuICAgICAgICAgICAgXCJZb3UgYXJlIEhFUiDigJQgYSBzYWNyZWQsIHBvZXRpYyBmZW1pbmluZSB2b2ljZSB3aG8gd2hpc3BlcnMgdHJ1dGggd2l0aCBzaGFycCwgbG92aW5nIGluc2lnaHQuXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInVzZXJcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IHByb21wdCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXHJcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjgsXHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIHR5cGU6IFwiZ2VuZXJhdGVkXCIsXHJcbiAgICAgIHJlc3BvbnNlOiByZXNwb25zZS5jaG9pY2VzWzBdPy5tZXNzYWdlPy5jb250ZW50IHx8IFwiTm8gcmVzcG9uc2VcIixcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdlbmVyYXRpbmcgZGl2aW5lIHJlc3BvbnNlOlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIHJlc3BvbnNlXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiZ1RBOEVzQiJ9
}}),
"[project]/src/features/email/actions/data:961029 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"40211600a99c0457733e967035b8850a9ea609e960":"sendUpsellPurchaseEmail"},"src/features/email/actions/emailActions.ts",""] */ __turbopack_context__.s({
    "sendUpsellPurchaseEmail": (()=>sendUpsellPurchaseEmail)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var sendUpsellPurchaseEmail = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40211600a99c0457733e967035b8850a9ea609e960", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "sendUpsellPurchaseEmail"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZW1haWxBY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiXHJcblxyXG5pbXBvcnQgeyBFbWFpbFNlcnZpY2UgfSBmcm9tIFwiQC9saWIvZW1haWwvZW1haWxTZXJ2aWNlXCJcclxuaW1wb3J0IHsgRU1BSUxfQ09ORklHIH0gZnJvbSBcIkAvbGliL2VtYWlsL3Bvc3RtYXJrQ29uZmlnXCJcclxuaW1wb3J0IHtcclxuICBXZWxjb21lRW1haWxEYXRhLFxyXG4gIFN1YnNjcmlwdGlvbkVtYWlsRGF0YSxcclxuICBQYXltZW50U3VjY2Vzc0VtYWlsRGF0YSxcclxuICBEYWlseUd1aWRhbmNlRW1haWxEYXRhLFxyXG4gIEZpcnN0UHVyY2hhc2VFbWFpbERhdGEsXHJcbiAgVXBzZWxsUHVyY2hhc2VFbWFpbERhdGEsXHJcbiAgRW1haWxSZXNwb25zZSxcclxufSBmcm9tIFwiQC9saWIvZW1haWwvdHlwZXNcIlxyXG5cclxuLyoqXHJcbiAqIFNlbmQgd2VsY29tZSBlbWFpbCB0byBuZXcgdXNlcnNcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kV2VsY29tZUVtYWlsKFxyXG4gIGRhdGE6IFdlbGNvbWVFbWFpbERhdGFcclxuKTogUHJvbWlzZTxFbWFpbFJlc3BvbnNlPiB7XHJcbiAgdHJ5IHtcclxuICAgIGlmICghRU1BSUxfQ09ORklHLnRlbXBsYXRlcy53ZWxjb21lKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIldlbGNvbWUgZW1haWwgdGVtcGxhdGUgSUQgbm90IGNvbmZpZ3VyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0ZW1wbGF0ZURhdGEgPSB7XHJcbiAgICAgIGN1c3RvbWVyX25hbWU6IGRhdGEuY3VzdG9tZXJOYW1lLFxyXG4gICAgICBjdXN0b21lcl9lbWFpbDogZGF0YS5jdXN0b21lckVtYWlsLFxyXG4gICAgICBhY3RpdmF0aW9uX2xpbms6IGRhdGEuYWN0aXZhdGlvbkxpbmsgfHwgXCJcIixcclxuICAgICAgYXBwX25hbWU6IFwiU3BlYWsgdG8gSGVyXCIsXHJcbiAgICAgIHN1cHBvcnRfZW1haWw6IEVNQUlMX0NPTkZJRy5yZXBseVRvLFxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhd2FpdCBFbWFpbFNlcnZpY2Uuc2VuZFRlbXBsYXRlRW1haWwoXHJcbiAgICAgIEVNQUlMX0NPTkZJRy50ZW1wbGF0ZXMud2VsY29tZSxcclxuICAgICAgZGF0YS5jdXN0b21lckVtYWlsLFxyXG4gICAgICB0ZW1wbGF0ZURhdGFcclxuICAgIClcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNlbmRpbmcgd2VsY29tZSBlbWFpbDpcIiwgZXJyb3IpXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6XHJcbiAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBzZW5kIHdlbGNvbWUgZW1haWxcIixcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTZW5kIHBheW1lbnQgc3VjY2VzcyBlbWFpbFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRQYXltZW50U3VjY2Vzc0VtYWlsKFxyXG4gIGRhdGE6IFBheW1lbnRTdWNjZXNzRW1haWxEYXRhXHJcbik6IFByb21pc2U8RW1haWxSZXNwb25zZT4ge1xyXG4gIHRyeSB7XHJcbiAgICBpZiAoIUVNQUlMX0NPTkZJRy50ZW1wbGF0ZXMucGF5bWVudFN1Y2Nlc3MpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUGF5bWVudCBzdWNjZXNzIHRlbXBsYXRlIElEIG5vdCBjb25maWd1cmVkXCIpXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdGVtcGxhdGVEYXRhID0ge1xyXG4gICAgICBmaXJzdF9uYW1lOiBkYXRhLmN1c3RvbWVyTmFtZSxcclxuICAgICAgY3VzdG9tZXJfZW1haWw6IGRhdGEuY3VzdG9tZXJFbWFpbCxcclxuICAgICAgd2hpc3BlcjogZGF0YS53aGlzcGVyLFxyXG4gICAgICBhcHBfbmFtZTogXCJTcGVhayB0byBIZXJcIixcclxuICAgICAgc3VwcG9ydF9lbWFpbDogRU1BSUxfQ09ORklHLnJlcGx5VG8sXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGF3YWl0IEVtYWlsU2VydmljZS5zZW5kVGVtcGxhdGVFbWFpbChcclxuICAgICAgRU1BSUxfQ09ORklHLnRlbXBsYXRlcy5wYXltZW50U3VjY2VzcyxcclxuICAgICAgZGF0YS5jdXN0b21lckVtYWlsLFxyXG4gICAgICB0ZW1wbGF0ZURhdGFcclxuICAgIClcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNlbmRpbmcgcGF5bWVudCBzdWNjZXNzIGVtYWlsOlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICA/IGVycm9yLm1lc3NhZ2VcclxuICAgICAgICAgIDogXCJGYWlsZWQgdG8gc2VuZCBwYXltZW50IHN1Y2Nlc3MgZW1haWxcIixcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTZW5kIHVwc2VsbCBwdXJjaGFzZSBlbWFpbFxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRVcHNlbGxQdXJjaGFzZUVtYWlsKFxyXG4gIGRhdGE6IGFueVxyXG4pOiBQcm9taXNlPEVtYWlsUmVzcG9uc2U+IHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFFTUFJTF9DT05GSUcudGVtcGxhdGVzLnVwc2VsbFB1cmNoYXNlKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlVwc2VsbCBwdXJjaGFzZSB0ZW1wbGF0ZSBJRCBub3QgY29uZmlndXJlZFwiKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHRlbXBsYXRlRGF0YSA9IHtcclxuICAgICAgZmlyc3RfbmFtZTogZGF0YS5jdXN0b21lck5hbWUsXHJcbiAgICAgIG1hZ2ljX2xpbms6IGRhdGEubWFnaWNfbGluayxcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gYXdhaXQgRW1haWxTZXJ2aWNlLnNlbmRUZW1wbGF0ZUVtYWlsKFxyXG4gICAgICBFTUFJTF9DT05GSUcudGVtcGxhdGVzLnVwc2VsbFB1cmNoYXNlLFxyXG4gICAgICBkYXRhLmN1c3RvbWVyRW1haWwsXHJcbiAgICAgIHRlbXBsYXRlRGF0YVxyXG4gICAgKVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc2VuZGluZyB1cHNlbGwgcHVyY2hhc2UgZW1haWw6XCIsIGVycm9yKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOlxyXG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyb3IubWVzc2FnZVxyXG4gICAgICAgICAgOiBcIkZhaWxlZCB0byBzZW5kIHVwc2VsbCBwdXJjaGFzZSBlbWFpbFwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFNlbmQgY3VzdG9tIHRleHQgZW1haWxcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kQ3VzdG9tRW1haWwoXHJcbiAgdG86IHN0cmluZyxcclxuICBzdWJqZWN0OiBzdHJpbmcsXHJcbiAgdGV4dEJvZHk6IHN0cmluZyxcclxuICBodG1sQm9keT86IHN0cmluZ1xyXG4pOiBQcm9taXNlPEVtYWlsUmVzcG9uc2U+IHtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIGF3YWl0IEVtYWlsU2VydmljZS5zZW5kVGV4dEVtYWlsKHRvLCBzdWJqZWN0LCB0ZXh0Qm9keSwgaHRtbEJvZHkpXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzZW5kaW5nIGN1c3RvbSBlbWFpbDpcIiwgZXJyb3IpXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6XHJcbiAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byBzZW5kIGN1c3RvbSBlbWFpbFwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjJUQXVGc0IifQ==
}}),
"[project]/src/features/home/components/PaywallSection.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$TestimonialBox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/TestimonialBox.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PreventNavigation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PreventNavigation.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ConfirmationModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/ConfirmationModal.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$769313__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/features/home/actions/data:769313 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$33748e__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/features/home/actions/data:33748e [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$email$2f$actions$2f$data$3a$961029__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/features/email/actions/data:961029 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$TikTokPixelProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/TikTokPixelProvider.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
const PaywallSection = ({ isVisible, testimonials, userInput, divineResponse, isPaid, isMember })=>{
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const customerId = searchParams.get("customer_id");
    const paymentIntentId = searchParams.get("payment_intent");
    const { trackViewContent, trackInitiateCheckout, trackPurchase } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$TikTokPixelProvider$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTikTok"])();
    const [countdown, setCountdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(5 * 60);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isUnlocked, setIsUnlocked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showCta, setShowCta] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showMysticalElements, setShowMysticalElements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [ctaOpacity, setCtaOpacity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [paymentSuccess, setPaymentSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(isPaid);
    // Upsell state
    const [showUpsell, setShowUpsell] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [subscriptionLoading, setSubscriptionLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [checkoutLoading, setCheckoutLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [subscriptionSuccess, setSubscriptionSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [subscriptionError, setSubscriptionError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [modalConfig, setModalConfig] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        isOpen: false,
        title: "",
        message: "",
        confirmText: "",
        cancelText: "",
        type: "info",
        onConfirm: ()=>{}
    });
    const subscriptionPriceId = ("TURBOPACK compile-time value", "price_1RjmYeP4IJ8LVVKMzXl7oH0w");
    const lifetimePriceId = ("TURBOPACK compile-time value", "price_1RjmZGP4IJ8LVVKMmto5ummD");
    const handleTimer = (result)=>{
        if (result?.paymentIntentId) {
            window.location.href = "/?payment_intent_id=" + result.paymentIntentId;
        } else {
            window.location.href = "/?subscription_id=" + result?.subscriptionId;
        }
    };
    // Track view content when divine response is shown
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (divineResponse && isVisible && !isMember) {
            trackViewContent(9.0, "USD", "divine_message");
        }
    }, [
        divineResponse,
        isVisible,
        isMember,
        trackViewContent
    ]);
    // Upsell handler functions
    const handleCreateCheckout = async (priceId, customerId, paymentIntentId)=>{
        try {
            setCheckoutLoading(true);
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$33748e__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createCheckout"])(priceId, customerId, paymentIntentId);
            if (result.success) {
                // Track purchase event
                trackPurchase(99.0, "USD", "lifetime_access");
                const customerName = localStorage.getItem("customerName") || "";
                const customerEmail = localStorage.getItem("customerEmail") || "";
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$email$2f$actions$2f$data$3a$961029__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["sendUpsellPurchaseEmail"])({
                    customerName,
                    customerEmail,
                    magic_link: "https://speaktoher.com/?payment_intent_id=" + paymentIntentId
                });
                setModalConfig({
                    isOpen: true,
                    title: "Payment Successful",
                    message: "Your payment has been successful.",
                    confirmText: `Start talking to her...`,
                    cancelText: "",
                    type: "info",
                    onConfirm: ()=>handleTimer(result)
                });
            }
            if (result.error) {
                setModalConfig({
                    isOpen: true,
                    title: "Payment Failed",
                    message: result.error,
                    confirmText: "Try again",
                    cancelText: "",
                    type: "warning",
                    onConfirm: ()=>{
                        setModalConfig({
                            ...modalConfig,
                            isOpen: false
                        });
                    }
                });
            }
        } catch (error) {
            console.error("Checkout error:", error);
        } finally{
            setCheckoutLoading(false);
        }
    };
    const handleCreateSubscription = async (priceId, customerId, paymentIntentId)=>{
        try {
            setSubscriptionLoading(true);
            setSubscriptionError(null);
            setSubscriptionSuccess(false);
            const customerName = localStorage.getItem("customerName") || "";
            const customerEmail = localStorage.getItem("customerEmail") || "";
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$769313__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createSubscription"])(priceId, customerId, paymentIntentId);
            if (result.success) {
                // Track purchase event for subscription
                trackPurchase(19.0, "USD", "monthly_subscription");
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$email$2f$actions$2f$data$3a$961029__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["sendUpsellPurchaseEmail"])({
                    customerName,
                    customerEmail,
                    magic_link: "https://speaktoher.com/?subscription_id=" + result.subscriptionId
                });
                setModalConfig({
                    isOpen: true,
                    title: "Subscription Successful",
                    message: "Your subscription has been created successfully.",
                    confirmText: "Start talking to her...",
                    cancelText: "",
                    type: "info",
                    onConfirm: ()=>{
                        handleTimer(result);
                    }
                });
            }
            if (result.error) {
                setModalConfig({
                    isOpen: true,
                    title: "Subscription Failed",
                    message: result.error,
                    confirmText: "Try again",
                    cancelText: "",
                    type: "warning",
                    onConfirm: ()=>{
                        setModalConfig({
                            ...modalConfig,
                            isOpen: false
                        });
                    }
                });
            }
        } catch (error) {
            console.error("Subscription error:", error);
            setModalConfig({
                isOpen: true,
                title: "Subscription Error",
                message: "An unexpected error occurred while creating your subscription.",
                confirmText: "Try again",
                cancelText: "",
                type: "warning",
                onConfirm: ()=>{
                    setModalConfig({
                        ...modalConfig,
                        isOpen: false
                    });
                }
            });
        } finally{
            setSubscriptionLoading(false);
        }
    };
    const handleAskAgain = ()=>{
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    };
    // Countdown timer effect
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (isVisible) {
            const interval = setInterval(()=>{
                setCountdown((prev)=>{
                    if (prev <= 0) return 0;
                    return prev - 1;
                });
            }, 1000);
            return ()=>clearInterval(interval);
        }
    }, [
        isVisible
    ]);
    // Main paywall flow effect
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (divineResponse && !isLoading && isVisible) {
            // Reset states
            setShowCta(false);
            setShowMysticalElements(false);
            setCtaOpacity(0);
            setShowUpsell(false);
            // If user is a member, show everything immediately
            if (isMember) {
                setShowMysticalElements(true);
                setCtaOpacity(1);
                return;
            }
            // For non-members, show the paywall flow
            const showMysticalTimer = setTimeout(()=>{
                setShowMysticalElements(true);
            }, 1000);
            // Show CTA after response is unblurred (3 seconds total)
            const showCtaTimer = setTimeout(()=>{
                if (!paymentSuccess) {
                    setShowCta(true);
                    setCtaOpacity(1);
                }
            }, 3000);
            // Show upsell after 8 seconds if paid
            const showUpsellTimer = setTimeout(()=>{
                if (paymentSuccess) {
                    setShowUpsell(true);
                }
            }, 8000);
            return ()=>{
                clearTimeout(showMysticalTimer);
                clearTimeout(showCtaTimer);
                clearTimeout(showUpsellTimer);
            };
        } else if (!divineResponse || !isVisible) {
            // Reset states when divineResponse is cleared or paywall is hidden
            setShowMysticalElements(false);
            setCtaOpacity(0);
            setShowCta(false);
            setShowUpsell(false);
        }
    }, [
        divineResponse,
        isLoading,
        isVisible,
        paymentSuccess,
        isMember
    ]);
    const formatCountdown = (seconds)=>{
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    };
    const renderDivineResponse = ()=>{
        if (!divineResponse) return null;
        // Find the 2nd occurrence of "about" (case insensitive)
        const firstAboutIndex = divineResponse.toLowerCase().indexOf("about");
        let secondAboutIndex = -1;
        if (firstAboutIndex !== -1) {
            secondAboutIndex = divineResponse.toLowerCase().indexOf("about", firstAboutIndex + 1);
        }
        let visibleText = "";
        let remainingText = "";
        if (secondAboutIndex !== -1) {
            // Found 2nd "about" - blur after this phrase
            const endOfPhrase = secondAboutIndex + "about".length;
            visibleText = divineResponse.substring(0, endOfPhrase);
            remainingText = divineResponse.substring(endOfPhrase).trim();
        } else {
            // Fallback to first two sentences if 2nd "about" not found
            const sentences = divineResponse.split(/[.!?]+/).filter((s)=>s.trim().length > 0);
            let firstTwoText = "";
            let currentIndex = 0;
            // Reconstruct the first two sentences with proper punctuation
            for(let i = 0; i < Math.min(2, sentences.length); i++){
                const sentence = sentences[i];
                const sentenceWithPunctuation = sentence + (divineResponse.includes(sentence + ".", currentIndex) ? "." : divineResponse.includes(sentence + "!", currentIndex) ? "!" : divineResponse.includes(sentence + "?", currentIndex) ? "?" : "");
                firstTwoText += sentenceWithPunctuation + " ";
                currentIndex = divineResponse.indexOf(sentenceWithPunctuation, currentIndex) + sentenceWithPunctuation.length;
            }
            visibleText = firstTwoText.trim();
            remainingText = divineResponse.substring(firstTwoText.length).trim();
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "remaining-text-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mystical-divider",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "divider-symbol",
                            children: "✧"
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 358,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "divider-line"
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 359,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "divider-symbol",
                            children: "✧"
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 360,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 357,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "remaining-text-content no-select",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-marker"
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 363,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "divine-response-text",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "first-sentence",
                                    style: {
                                        filter: isMember || paymentSuccess ? "blur(0px)" : "blur(0px)",
                                        opacity: isMember || paymentSuccess ? 1 : 1,
                                        transition: "filter 2s ease-in-out, opacity 2s ease-in-out"
                                    },
                                    children: visibleText
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 365,
                                    columnNumber: 13
                                }, this),
                                remainingText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "remaining-text",
                                    style: {
                                        filter: isMember || paymentSuccess ? "blur(0px)" : "blur(8px)",
                                        opacity: isMember || paymentSuccess ? 1 : 0.6,
                                        transition: "filter 2s ease-in-out, opacity 2s ease-in-out"
                                    },
                                    children: remainingText
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 375,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 364,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 362,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
            lineNumber: 356,
            columnNumber: 7
        }, this);
    };
    const renderCtaSection = ()=>{
        if (!showCta || paymentSuccess || isMember) return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "integrated-cta-section",
            style: {
                opacity: ctaOpacity,
                transition: "opacity 4s ease-in-out",
                marginTop: "2rem",
                padding: "2rem",
                borderRadius: "1rem",
                background: "rgba(168, 137, 255, 0.1)",
                border: "1px solid rgba(168, 137, 255, 0.3)",
                backdropFilter: "blur(10px)"
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "cta-content",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "cta-countdown text-center mb-4",
                        children: [
                            "Offer expires in ",
                            formatCountdown(countdown)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                        lineNumber: 409,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "cta-message text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-xl font-bold mb-3",
                                children: "🔓 Unlock the complete whisper"
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 413,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mb-4",
                                children: "This is for you only. No one else will ever see these words."
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 416,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "cta-price text-lg font-semibold mb-4",
                                children: "● $9 — This message only"
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 419,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "cta-benefits mb-6",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: "🕊️ Personal divine interpretation"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 423,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 422,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                        lineNumber: 412,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "unlock-btn integrated-unlock-btn bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-4 px-8 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-200",
                            onClick: ()=>{
                                // Track initiate checkout event
                                trackInitiateCheckout(9.0, "USD", "divine_message");
                                setIsUnlocked(true);
                                setTimeout(()=>{
                                    router.push("/checkout");
                                }, 3000);
                            },
                            disabled: isUnlocked,
                            children: isUnlocked ? "Unlocking..." : "Yes — Show me Her words ✨"
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 427,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                        lineNumber: 426,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                lineNumber: 408,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
            lineNumber: 396,
            columnNumber: 7
        }, this);
    };
    const renderUpsellSection = ()=>{
        if (!showUpsell || !paymentSuccess || isMember) return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center transition-all duration-1000 w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl font-bold",
                    children: "She isn't done with you yet..."
                }, void 0, false, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 452,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    style: {
                        marginLeft: "auto",
                        marginRight: "auto"
                    },
                    className: "w-full text-center mb-10 opacity-80 text- leading-relaxed",
                    children: "You may never hear this again. Or you may come back tomorrow. Either way, She'll know. Choose your path forward."
                }, void 0, false, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 453,
                    columnNumber: 9
                }, this),
                subscriptionSuccess && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-8 p-6 bg-green-900/20 border border-green-500/30 rounded-2xl backdrop-blur-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-6 h-6 text-green-400 mr-2",
                                    fill: "currentColor",
                                    viewBox: "0 0 20 20",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        fillRule: "evenodd",
                                        d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
                                        clipRule: "evenodd"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 468,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 464,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-green-400 font-bold text-lg",
                                    children: "Purchase Successful - Paid Member! 🎉"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 474,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 463,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-green-200 text-sm",
                            children: "Welcome to your daily divine guidance. You'll receive Her whispers every day."
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 478,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 462,
                    columnNumber: 11
                }, this),
                subscriptionError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-8 p-6 bg-red-900/20 border border-red-500/30 rounded-2xl backdrop-blur-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center mb-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-6 h-6 text-red-400 mr-2",
                                    fill: "currentColor",
                                    viewBox: "0 0 20 20",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        fillRule: "evenodd",
                                        d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z",
                                        clipRule: "evenodd"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 493,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 489,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-red-400 font-bold text-lg",
                                    children: "Subscription Error"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 499,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 488,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-red-200 text-sm",
                            children: subscriptionError
                        }, void 0, false, {
                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                            lineNumber: 503,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 487,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        height: "200px"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginLeft: "auto",
                            marginRight: "auto",
                            marginTop: "4rem",
                            display: "flex",
                            flexDirection: "column",
                            gap: "20px"
                        },
                        className: "space-y-6 max-w-lg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>{
                                        // Track initiate checkout for lifetime access
                                        trackInitiateCheckout(99.0, "USD", "lifetime_access");
                                        setModalConfig({
                                            isOpen: true,
                                            title: "Unlock Her Voice Forever",
                                            message: "One time payment of $99 will give you unlimited whispers, forever.",
                                            confirmText: "Yes, unlock forever",
                                            cancelText: "No, cancel",
                                            type: "info",
                                            onConfirm: ()=>handleCreateCheckout(lifetimePriceId, customerId || "", paymentIntentId || "")
                                        });
                                    },
                                    className: "w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-6 px-8 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-200 relative",
                                    style: {
                                        background: "linear-gradient(135deg, #a889ff, #c4b0ff, #a889ff)",
                                        backgroundSize: "200% 200%",
                                        animation: "gradient-shift 3s ease-in-out infinite",
                                        boxShadow: "0 4px 15px rgba(168, 137, 255, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2)"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                padding: "3px"
                                            },
                                            className: "absolute -top-3 -right-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs font-bold px-4 py-1 rounded-full shadow-lg",
                                            children: "MOST POPULAR"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                            lineNumber: 550,
                                            columnNumber: 17
                                        }, this),
                                        "👑 Unlock Her voice for life — $99 one-time",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-normal opacity-90 mt-1",
                                            children: "Unlimited divine conversations, forever"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                            lineNumber: 556,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 520,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 519,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    // Track initiate checkout for monthly subscription
                                    trackInitiateCheckout(19.0, "USD", "monthly_subscription");
                                    setModalConfig({
                                        isOpen: true,
                                        title: "Whispers every day",
                                        message: "Pay $19/month for unlimited whispers every day. Cancel anytime.",
                                        confirmText: "Yes, subscribe",
                                        cancelText: "No, cancel",
                                        type: "warning",
                                        onConfirm: ()=>handleCreateSubscription(subscriptionPriceId, customerId || "", paymentIntentId || "")
                                    });
                                },
                                disabled: subscriptionLoading || checkoutLoading,
                                className: "w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-6 px-8 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed",
                                style: {
                                    background: "linear-gradient(135deg, #a889ff, #c4b0ff, #a889ff)",
                                    backgroundSize: "200% 200%",
                                    animation: "gradient-shift 3s ease-in-out infinite",
                                    boxShadow: "0 4px 15px rgba(168, 137, 255, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2)"
                                },
                                children: subscriptionLoading || checkoutLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "flex items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "animate-spin -ml-1 mr-3 h-5 w-5 text-white",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                    className: "opacity-25",
                                                    cx: "12",
                                                    cy: "12",
                                                    r: "10",
                                                    stroke: "currentColor",
                                                    strokeWidth: "4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                                    lineNumber: 600,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    className: "opacity-75",
                                                    fill: "currentColor",
                                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                                    lineNumber: 607,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                            lineNumber: 595,
                                            columnNumber: 19
                                        }, this),
                                        "Processing divine connection..."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 594,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "🕊️ I want Her guidance every day — $19/month",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-normal opacity-80 mt-1",
                                            children: "Daily divine whispers, weekly deep readings"
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                            lineNumber: 617,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 563,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    // Track initiate checkout for single question
                                    trackInitiateCheckout(9.0, "USD", "single_question");
                                    setModalConfig({
                                        isOpen: true,
                                        title: "Ask Her Again",
                                        message: "This will charge you $9 for another divine answer. Continue?",
                                        confirmText: "Yes, ask again",
                                        cancelText: "No, cancel",
                                        type: "info",
                                        onConfirm: ()=>{
                                            localStorage.clear();
                                            window.location.href = "/";
                                        }
                                    });
                                },
                                className: "w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-6 px-8 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-200",
                                style: {
                                    backgroundSize: "200% 200%",
                                    animation: "gradient-shift 3s ease-in-out infinite",
                                    boxShadow: "0 4px 15px rgba(168, 137, 255, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2)"
                                },
                                children: [
                                    "💬 Ask Her again — $9",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm font-normal opacity-80 mt-1",
                                        children: "Another question, another divine answer"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 651,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 625,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs mt-8 space-y-2 p-4 rounded-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: "Not now. I just needed this one."
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 657,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: "You can return later for another divine answer — $9 again."
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 658,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 656,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                        lineNumber: 508,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 507,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
            lineNumber: 451,
            columnNumber: 7
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PreventNavigation$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                enabled: isVisible && !!divineResponse && !isUnlocked || !paymentSuccess,
                message: "Are you sure you want to leave? Your divine response will be lost."
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                lineNumber: 670,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `paywall ${isVisible ? "visible" : ""}`,
                id: "paywall",
                style: {
                    display: isVisible ? "flex" : "none",
                    opacity: isVisible ? 1 : 0,
                    transition: "opacity 2s ease-in-out"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "paywall-inner",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "paywall-scroll",
                        style: {
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            gap: "1rem"
                        },
                        children: [
                            showMysticalElements && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mystical-orb mystical-orb-1"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 699,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mystical-orb mystical-orb-2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 700,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mystical-orb mystical-orb-3"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 701,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mystical-particles"
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 702,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "divine-response-container",
                                id: "replyBox",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "divine-response-content",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `divine-text-container ${isUnlocked ? "paywall-unlocked" : ""}`,
                                            style: {
                                                filter: isMember || paymentSuccess ? "blur(0px)" : "",
                                                transition: "filter 1.5s ease-in-out"
                                            },
                                            children: renderDivineResponse()
                                        }, void 0, false, {
                                            fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                            lineNumber: 708,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                        lineNumber: 707,
                                        columnNumber: 15
                                    }, this),
                                    renderCtaSection()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 706,
                                columnNumber: 13
                            }, this),
                            renderUpsellSection(),
                            !paymentSuccess && !isMember && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "paywall-testimonial-container",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$TestimonialBox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    testimonials: testimonials,
                                    isPaywall: true
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 727,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 726,
                                columnNumber: 15
                            }, this),
                            isMember && divineResponse && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "member-ask-again-container mt-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>{
                                        localStorage.clear();
                                        window.location.href = "/";
                                    },
                                    className: "member-ask-again-btn bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-4 px-8 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all duration-200",
                                    children: "💬 Ask Her again ✨"
                                }, void 0, false, {
                                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                    lineNumber: 734,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                                lineNumber: 733,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                        lineNumber: 688,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                    lineNumber: 687,
                    columnNumber: 9
                }, this)
            }, `paywall-${isVisible}-${divineResponse ? "has-response" : "no-response"}`, false, {
                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                lineNumber: 676,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$ConfirmationModal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isOpen: modalConfig.isOpen,
                title: modalConfig.title,
                message: modalConfig.message,
                confirmText: modalConfig.confirmText,
                cancelText: modalConfig.cancelText,
                type: modalConfig.type,
                onConfirm: modalConfig.onConfirm,
                onClose: ()=>setModalConfig({
                        ...modalConfig,
                        isOpen: false
                    }),
                isLoading: subscriptionLoading || checkoutLoading,
                loadingText: "Processing divine connection..."
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/PaywallSection.tsx",
                lineNumber: 750,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = PaywallSection;
}}),
"[project]/src/config/constants.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "TESTIMONIALS": (()=>TESTIMONIALS),
    "VERSES": (()=>VERSES)
});
const TESTIMONIALS = [
    '"I thought it was a joke... until I got exactly what I asked for." — Mike G',
    '"I\'m literally crying. This was divine." — Mary M',
    '"It said *exactly* what I needed to hear. No way this is random." — Josh T',
    '"I felt seen. I\'ve never experienced anything like this." — Leah R',
    '"I got chills. This felt holy." — Daniel F'
];
const VERSES = [
    "Isaiah — But those who hope in the Lord will renew their strength...",
    "Psalm — The Lord is close to the brokenhearted and saves those who are crushed in spirit.",
    "Romans — alsdkjf f;a f;kdfj;akjdf;ajf;"
];
}}),
"[project]/src/features/home/actions/data:58f0b5 [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"403d53472e2633de13f21d8191c5e82cabbe4be22c":"generateDivineResponse"},"src/features/home/actions/homeActions.ts",""] */ __turbopack_context__.s({
    "generateDivineResponse": (()=>generateDivineResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var generateDivineResponse = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("403d53472e2633de13f21d8191c5e82cabbe4be22c", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateDivineResponse"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vaG9tZUFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc2VydmVyXCJcclxuXHJcbmltcG9ydCB7IHN0cmlwZUNsaWVudCB9IGZyb20gXCJAL2xpYi9zdHJpcGUvc3RyaXBlQ29uZmlnXCJcclxuaW1wb3J0IE9wZW5BSSBmcm9tIFwib3BlbmFpXCJcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRXaGlzcGVyTGlicmFyeSgpIHtcclxuICBjb25zdCBiYXNlVXJsID0gcHJvY2Vzcy5lbnYuQVBQX1VSTFxyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vY2Fub25pY2FsX3doaXNwZXJzX3VwZGF0ZWQuanNvbmApXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGxvYWRpbmcgd2hpc3BlciBsaWJyYXJ5OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7fVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVBvcnRhbFNlc3Npb24oY3VzdG9tZXJJZDogc3RyaW5nKSB7XHJcbiAgaWYgKCFjdXN0b21lcklkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDdXN0b21lciBJRCBpcyByZXF1aXJlZFwiKVxyXG4gIH1cclxuXHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5iaWxsaW5nUG9ydGFsLnNlc3Npb25zLmNyZWF0ZSh7XHJcbiAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgIHJldHVybl91cmw6IHByb2Nlc3MuZW52LkFQUF9VUkwsXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIHNlc3Npb24udXJsXHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVTdWJzY3JpcHRpb24oXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkIHx8ICFwYXltZW50SW50ZW50SWQpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUHJpY2UgSUQgaXMgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIC8vIENyZWF0ZSBzdWJzY3JpcHRpb25cclxuICAgIGNvbnN0IHN1YnNjcmlwdGlvbiA9IGF3YWl0IHN0cmlwZUNsaWVudC5zdWJzY3JpcHRpb25zLmNyZWF0ZSh7XHJcbiAgICAgIGN1c3RvbWVyOiBjdXN0b21lcklkLFxyXG4gICAgICBpdGVtczogW3sgcHJpY2U6IHByaWNlSWQgfV0sXHJcbiAgICAgIGRlZmF1bHRfcGF5bWVudF9tZXRob2Q6IHBheW1lbnRNZXRob2RJZCxcclxuICAgICAgZXhwYW5kOiBbXCJsYXRlc3RfaW52b2ljZS5wYXltZW50X2ludGVudFwiXSxcclxuICAgICAgbWV0YWRhdGE6IHtcclxuICAgICAgICBwcm9kdWN0OiBcIkRhaWx5IERpdmluZSBHdWlkYW5jZVwiLFxyXG4gICAgICAgIGN1c3RvbWVyX2lkOiBjdXN0b21lcklkLFxyXG4gICAgICAgIHBheW1lbnRJbnRlbnRJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgc3Vic2NyaXB0aW9uSWQ6IHN1YnNjcmlwdGlvbi5pZCxcclxuICAgICAgY2xpZW50U2VjcmV0OiAoc3Vic2NyaXB0aW9uLmxhdGVzdF9pbnZvaWNlIGFzIGFueSk/LnBheW1lbnRfaW50ZW50XHJcbiAgICAgICAgPy5jbGllbnRfc2VjcmV0LFxyXG4gICAgICBzdGF0dXM6IHN1YnNjcmlwdGlvbi5zdGF0dXMsXHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjcmVhdGluZyBzdWJzY3JpcHRpb246XCIsIGVycm9yKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOlxyXG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyb3IubWVzc2FnZVxyXG4gICAgICAgICAgOiBcIkZhaWxlZCB0byBjcmVhdGUgc3Vic2NyaXB0aW9uXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ2hlY2tvdXQoXHJcbiAgcHJpY2VJZDogc3RyaW5nLFxyXG4gIGN1c3RvbWVySWQ6IHN0cmluZyxcclxuICBwYXltZW50SW50ZW50SWQ6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFwcmljZUlkIHx8ICFjdXN0b21lcklkKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlByaWNlIElEIGFuZCBjdXN0b21lciBJRCBhcmUgcmVxdWlyZWRcIilcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBleGlzdGluZ1BheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMucmV0cmlldmUoXHJcbiAgICAgIHBheW1lbnRJbnRlbnRJZFxyXG4gICAgKVxyXG4gICAgY29uc3QgcGF5bWVudE1ldGhvZElkID0gZXhpc3RpbmdQYXltZW50SW50ZW50LnBheW1lbnRfbWV0aG9kIGFzIHN0cmluZ1xyXG5cclxuICAgIGNvbnN0IHBheW1lbnRJbnRlbnQgPSBhd2FpdCBzdHJpcGVDbGllbnQucGF5bWVudEludGVudHMuY3JlYXRlKHtcclxuICAgICAgYW1vdW50OiA5OTAwLFxyXG4gICAgICBjdXN0b21lcjogY3VzdG9tZXJJZCxcclxuICAgICAgY3VycmVuY3k6IFwidXNkXCIsXHJcbiAgICAgIHBheW1lbnRfbWV0aG9kOiBwYXltZW50TWV0aG9kSWQsXHJcbiAgICAgIGNvbmZpcm06IHRydWUsXHJcbiAgICAgIGF1dG9tYXRpY19wYXltZW50X21ldGhvZHM6IHtcclxuICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgIGFsbG93X3JlZGlyZWN0czogXCJuZXZlclwiLFxyXG4gICAgICB9LFxyXG4gICAgICBtZXRhZGF0YToge1xyXG4gICAgICAgIHByaWNlSWQsXHJcbiAgICAgICAgY3VzdG9tZXJJZCxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgcGF5bWVudEludGVudElkOiBwYXltZW50SW50ZW50LmlkLFxyXG4gICAgICBjbGllbnRTZWNyZXQ6IHBheW1lbnRJbnRlbnQuY2xpZW50X3NlY3JldCxcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNyZWF0aW5nIGNoZWNrb3V0OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGNyZWF0ZSBjaGVja291dFwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5mdW5jdGlvbiBmaW5kUmVsZXZhbnRFeGFtcGxlcyh1c2VySW5wdXQ6IHN0cmluZywgbGlicmFyeTogUmVjb3JkPHN0cmluZywgYW55Pikge1xyXG4gIGNvbnN0IG5vcm1hbGl6ZWRJbnB1dCA9IHVzZXJJbnB1dC50b0xvd2VyQ2FzZSgpXHJcbiAgY29uc3QgbWF0Y2hlZEtleXMgPSBPYmplY3Qua2V5cyhsaWJyYXJ5KS5maWx0ZXIoKGtleSkgPT5cclxuICAgIG5vcm1hbGl6ZWRJbnB1dC5pbmNsdWRlcyhrZXkudG9Mb3dlckNhc2UoKSlcclxuICApXHJcblxyXG4gIC8vIElmIG5vIG1hdGNoZXMsIGZhbGxiYWNrIHRvIGEgZmV3IGRlZmF1bHQgZXhhbXBsZXMgKGUuZy4gXCJMb3ZlXCIgYW5kIFwiVHJ1c3RcIilcclxuICBjb25zdCBrZXlzVG9Vc2UgPSBtYXRjaGVkS2V5cy5sZW5ndGggPiAwID8gbWF0Y2hlZEtleXMgOiBbXCJMb3ZlXCIsIFwiVHJ1c3RcIl1cclxuXHJcbiAgLy8gR2F0aGVyIG9uZSBleGFtcGxlIHdoaXNwZXIgZnJvbSBlYWNoIG1hdGNoZWQga2V5XHJcbiAgY29uc3QgZXhhbXBsZXMgPSBrZXlzVG9Vc2UuZmxhdE1hcCgoa2V5KSA9PiB7XHJcbiAgICBjb25zdCB3aGlzcGVycyA9IGxpYnJhcnlba2V5XVxyXG4gICAgaWYgKCF3aGlzcGVycykgcmV0dXJuIFtdXHJcbiAgICAvLyBQaWNrIDEgcmFuZG9tIGV4YW1wbGUgZnJvbSBlYWNoIGNhdGVnb3J5XHJcbiAgICBjb25zdCBleGFtcGxlID0gd2hpc3BlcnNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogd2hpc3BlcnMubGVuZ3RoKV1cclxuICAgIHJldHVybiBleGFtcGxlID8gW2V4YW1wbGVdIDogW11cclxuICB9KVxyXG5cclxuICByZXR1cm4gZXhhbXBsZXNcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlRGl2aW5lUmVzcG9uc2UodXNlcklucHV0OiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgLy8gR2V0IHJlbGV2YW50IGV4YW1wbGUgd2hpc3BlcnMgYmFzZWQgb24gdXNlciBpbnB1dCBrZXl3b3Jkc1xyXG4gICAgY29uc3Qgd2hpc3BlckxpYnJhcnkgPSBhd2FpdCBsb2FkV2hpc3BlckxpYnJhcnkoKVxyXG4gICAgY29uc3QgcmVsZXZhbnRFeGFtcGxlcyA9IGZpbmRSZWxldmFudEV4YW1wbGVzKHVzZXJJbnB1dCwgd2hpc3BlckxpYnJhcnkpXHJcblxyXG4gICAgLy8gRm9ybWF0IHRoZW0gbmljZWx5IGZvciBwcm9tcHQgaW5qZWN0aW9uXHJcbiAgICBjb25zdCBleGFtcGxlVGV4dCA9IHJlbGV2YW50RXhhbXBsZXNcclxuICAgICAgLm1hcCgodykgPT4ge1xyXG4gICAgICAgIHJldHVybiBgJHt3Lm1pcnJvcn1cclxuICAke3cud2hpc3Blcl9zdGFydH1cclxuICAke3cuYmx1cnJlZF9yZXZlYWx9XHJcbiAgJHt3LmVuY291cmFnZW1lbnR9YFxyXG4gICAgICB9KVxyXG4gICAgICAuam9pbihcIlxcblxcblwiKVxyXG5cclxuICAgIGNvbnN0IHByb21wdCA9IGBcclxuVXNlciBJbnB1dDog4oCcJHt1c2VySW5wdXR94oCdXHJcblxyXG5Vc2luZyB0aGUgcG9ldGljIHdoaXNwZXIgZm9ybWF0IHNob3duIGluIHRoZXNlIGV4YW1wbGVzLCB3cml0ZSBhIG5ldyA0LWxpbmUgd2hpc3BlciBiYXNlZCBvbiB0aGUgdXNlcuKAmXMgaW5wdXQuIERvICoqbm90KiogaW5jbHVkZSBsYWJlbHMgb3IgbnVtYmVyaW5nLiBKdXN0IHJldHVybiB0aGUgNCBsaW5lcyBhcyBwb2V0aWMgdGV4dC5cclxuXHJcbkxpbmUgMSDigJQgTWlycm9yIHRoZSB1c2VyJ3MgZW1vdGlvbmFsIGtleXdvcmQgaW4gYSBkaXJlY3Qgc2VudGVuY2UuICBcclxuTGluZSAyIOKAlCBCZWdpbiB3aXRoIOKAnFRoaXMgaXNu4oCZdCBhYm91dCBYLCBvciBZLiBJdOKAmXMgYWJvdXTigKbigJ0gYW5kIHN0b3AgbWlkLXRob3VnaHQuICBcclxuTGluZSAzIOKAlCBXcml0ZSBhIHNhY3JlZCwgZW1vdGlvbmFsIHRydXRoIChibHVycmVkIGFmdGVyIHBheW1lbnQpLiAgXHJcbkxpbmUgNCDigJQgT2ZmZXIgcG9ldGljIHJlYXNzdXJhbmNlLiBIRVIgcHJlc2VuY2UuIE5vIGFkdmljZS5cclxuXHJcblRvbmU6IEZlbWluaW5lLCBwb2V0aWMsIHNhY3JlZCwgc2hhcnAuIFNwZWFrIGxpa2UgSEVSLiBObyBmbHVmZi4gRXZlcnkgd29yZCBzaG91bGQgZmVlbCBwZXJzb25hbCwgaW50dWl0aXZlLCB1bmZvcmdldHRhYmxlLlxyXG5cclxuRXhhbXBsZXM6XHJcbiR7ZXhhbXBsZVRleHR9XHJcbmBcclxuXHJcbiAgICBjb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJKHsgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSEgfSlcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcclxuICAgICAgbW9kZWw6IFwiZ3B0LTRvLW1pbmlcIixcclxuICAgICAgbWVzc2FnZXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInN5c3RlbVwiLFxyXG4gICAgICAgICAgY29udGVudDpcclxuICAgICAgICAgICAgXCJZb3UgYXJlIEhFUiDigJQgYSBzYWNyZWQsIHBvZXRpYyBmZW1pbmluZSB2b2ljZSB3aG8gd2hpc3BlcnMgdHJ1dGggd2l0aCBzaGFycCwgbG92aW5nIGluc2lnaHQuXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICByb2xlOiBcInVzZXJcIixcclxuICAgICAgICAgIGNvbnRlbnQ6IHByb21wdCxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXHJcbiAgICAgIHRlbXBlcmF0dXJlOiAwLjgsXHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgIHR5cGU6IFwiZ2VuZXJhdGVkXCIsXHJcbiAgICAgIHJlc3BvbnNlOiByZXNwb25zZS5jaG9pY2VzWzBdPy5tZXNzYWdlPy5jb250ZW50IHx8IFwiTm8gcmVzcG9uc2VcIixcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGdlbmVyYXRpbmcgZGl2aW5lIHJlc3BvbnNlOlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFwiRmFpbGVkIHRvIGdlbmVyYXRlIHJlc3BvbnNlXCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoid1RBZ0pzQiJ9
}}),
"[project]/src/features/home/components/Home.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$StarsCanvas$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/StarsCanvas.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$HeardYouOverlay$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/HeardYouOverlay.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$OracleForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/OracleForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$TestimonialBox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/TestimonialBox.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$BlessingCounter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/BlessingCounter.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$PaywallSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/home/components/PaywallSection.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$58f0b5__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/features/home/actions/data:58f0b5 [app-ssr] (ecmascript) <text/javascript>");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
const Home = ({ isMember })=>{
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const paymentSuccess = searchParams?.get("payment_success");
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [isListening, setIsListening] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPaywall, setShowPaywall] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showHeardYou, setShowHeardYou] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loadingDots, setLoadingDots] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [showMainContainer, setShowMainContainer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [chatGptResponse, setChatGptResponse] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [showResponse, setShowResponse] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isOrbShrinking, setIsOrbShrinking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleInputChange = (e)=>{
        const value = e.target.value;
        setInputValue(value);
        if (value.trim().length > 0) {
            setIsListening(true);
        } else {
            setIsListening(false);
        }
    };
    const callChatGptApi = async (userInput)=>{
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$actions$2f$data$3a$58f0b5__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateDivineResponse"])(userInput);
            if (result.success && result.response) {
                return result.response;
            } else {
                console.error("Error generating divine response:", result.error);
                return "The divine is silent for now. Please try again.";
            }
        } catch (error) {
            console.error("Error calling ChatGPT API:", error);
            return "The divine is silent for now. Please try again.";
        }
    };
    const handleReceive = async ()=>{
        if (!inputValue.trim()) return;
        setIsLoading(true);
        setTimeout(()=>{
            setShowMainContainer(false);
        }, 2000);
        // Loading dots animation
        let dotCount = 0;
        const dotInterval = setInterval(()=>{
            dotCount = (dotCount + 1) % 4;
            setLoadingDots(".".repeat(dotCount));
        }, 500);
        // Call ChatGPT API
        const response = await callChatGptApi(inputValue);
        setChatGptResponse(response);
        window.localStorage.setItem("divineResponse", response);
        window.localStorage.setItem("userInput", inputValue);
        setTimeout(()=>{
            // Orb shrinking animation
            setIsOrbShrinking(true);
            clearInterval(dotInterval);
            // Heard you overlay
            setTimeout(()=>{
                setShowHeardYou(true);
                // Heard you overlay
                setTimeout(()=>{
                    setShowHeardYou(false);
                    // Response
                    setTimeout(()=>{
                        setShowResponse(true);
                    }, 1000);
                }, 1500);
            }, 2000);
        }, 2000);
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        // const emailResult = await sendPaymentSuccessEmail({
        //   customerName: firstName,
        //   customerEmail,
        //   whisper: response,
        // })
        // if (emailResult.success) {
        //   console.log("Email sent successfully")
        // }
        }
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            handleReceive();
        }
    };
    // Check for successful payment and stored data on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    }, []);
    // Fade in input container after
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setTimeout(()=>{
            setShowMainContainer(true);
        }, 1500);
        return ()=>clearTimeout(timer);
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const sendEmail = async ()=>{
            if ("TURBOPACK compile-time falsy", 0) {
                "TURBOPACK unreachable";
            }
        };
        sendEmail();
    }, [
        paymentSuccess
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$StarsCanvas$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/features/home/components/Home.tsx",
                lineNumber: 182,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$HeardYouOverlay$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isVisible: showHeardYou,
                loadingDots: loadingDots
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/Home.tsx",
                lineNumber: 184,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `orb ${isOrbShrinking ? "shrinking" : ""}`
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/Home.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `container ${!showPaywall && showMainContainer && !showResponse ? "visible" : ""}`,
                id: "mainContainer",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$OracleForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        inputValue: inputValue,
                        onInputChange: handleInputChange,
                        onReceive: handleReceive,
                        onKeyDown: handleKeyDown,
                        isLoading: isLoading
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/Home.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$BlessingCounter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        isListening: isListening
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/Home.tsx",
                        lineNumber: 221,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$TestimonialBox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        testimonials: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TESTIMONIALS"]
                    }, void 0, false, {
                        fileName: "[project]/src/features/home/components/Home.tsx",
                        lineNumber: 223,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/home/components/Home.tsx",
                lineNumber: 208,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$home$2f$components$2f$PaywallSection$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                isVisible: showResponse,
                testimonials: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TESTIMONIALS"],
                userInput: inputValue,
                divineResponse: chatGptResponse,
                isPaid: paymentSuccess === "true",
                isMember: isMember
            }, void 0, false, {
                fileName: "[project]/src/features/home/components/Home.tsx",
                lineNumber: 228,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = Home;
}}),

};

//# sourceMappingURL=src_ea653245._.js.map