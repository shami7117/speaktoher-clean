(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[root-of-the-server]__3f3d5ff4._.js", {

"[externals]/node:buffer [external] (node:buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[project]/src/lib/stripe/stripeEdgeClient.ts [middleware-edge] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "StripeEdgeClient": (()=>StripeEdgeClient),
    "stripeEdgeClient": (()=>stripeEdgeClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$dist$2f$esm$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/dist/esm/index.js [middleware-edge] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$dist$2f$esm$2f$v3$2f$external$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/dist/esm/v3/external.js [middleware-edge] (ecmascript) <export * as z>");
"server-only";
;
// Environment variable validation
const requiredEnvVars = {
    STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY
};
function validateEnvironment() {
    const envSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$dist$2f$esm$2f$v3$2f$external$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        STRIPE_SECRET_KEY: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$dist$2f$esm$2f$v3$2f$external$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, "STRIPE_SECRET_KEY is required")
    });
    try {
        envSchema.parse(requiredEnvVars);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$dist$2f$esm$2f$v3$2f$external$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].ZodError) {
            const missingVars = error.errors.map((err)=>err.path.join(".")).join(", ");
            throw new Error(`Missing required environment variables: ${missingVars}`);
        }
        throw error;
    }
}
class StripeEdgeClient {
    baseUrl = "https://api.stripe.com/v1";
    secretKey;
    constructor(){
        validateEnvironment();
        this.secretKey = requiredEnvVars.STRIPE_SECRET_KEY;
    }
    async makeRequest(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        const auth = btoa(this.secretKey + ":");
        const response = await fetch(url, {
            ...options,
            headers: {
                Authorization: `Basic ${auth}`,
                "Content-Type": "application/x-www-form-urlencoded",
                ...options.headers
            }
        });
        if (!response.ok) {
            throw new Error(`Stripe API error: ${response.status} ${response.statusText}`);
        }
        return response.json();
    }
    async retrievePaymentIntent(paymentIntentId) {
        return this.makeRequest(`/payment_intents/${paymentIntentId}`);
    }
    async retrieveSubscription(subscriptionId) {
        return this.makeRequest(`/subscriptions/${subscriptionId}`);
    }
}
const stripeEdgeClient = new StripeEdgeClient();
}}),
"[project]/src/middleware.ts [middleware-edge] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "config": (()=>config),
    "default": (()=>middleware)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeEdgeClient$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/stripe/stripeEdgeClient.ts [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/spec-extension/response.js [middleware-edge] (ecmascript)");
;
;
let customerId = "";
let isMember = false;
async function getIsMember(paymentIntentId) {
    const paymentIntent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeEdgeClient$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["stripeEdgeClient"].retrievePaymentIntent(paymentIntentId);
    const isMember = paymentIntent.status === "succeeded" && paymentIntent.metadata?.customerId !== undefined;
    customerId = isMember ? paymentIntent.metadata?.customerId || "" : "";
    return isMember;
}
async function getIsMemberBySubscriptionId(subscriptionId) {
    const subscription = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$stripe$2f$stripeEdgeClient$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["stripeEdgeClient"].retrieveSubscription(subscriptionId);
    const isMember = subscription.status === "active";
    customerId = isMember ? subscription.customer : "";
    return isMember;
}
async function middleware(request) {
    const { searchParams } = new URL(request.url);
    const paymentIntentId = searchParams.get("payment_intent_id");
    const subscriptionId = searchParams.get("subscription_id");
    if (paymentIntentId) {
        const response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
        isMember = await getIsMember(paymentIntentId);
        if (isMember) {
            response.cookies.set("customer_id", customerId, {
                httpOnly: ("TURBOPACK compile-time value", "development") === "production",
                secure: ("TURBOPACK compile-time value", "development") === "production",
                sameSite: "lax",
                path: "/"
            });
            // Set cookie with payment intent ID
            response.cookies.set("is_member", "true", {
                httpOnly: ("TURBOPACK compile-time value", "development") === "production",
                secure: ("TURBOPACK compile-time value", "development") === "production",
                sameSite: "lax",
                path: "/"
            });
        }
        return response;
    } else if (subscriptionId) {
        const response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
        isMember = await getIsMemberBySubscriptionId(subscriptionId);
        if (isMember) {
            response.cookies.set("customer_id", customerId, {
                httpOnly: ("TURBOPACK compile-time value", "development") === "production",
                secure: ("TURBOPACK compile-time value", "development") === "production",
                sameSite: "lax",
                path: "/"
            });
            response.cookies.set("is_member", "true", {
                httpOnly: ("TURBOPACK compile-time value", "development") === "production",
                secure: ("TURBOPACK compile-time value", "development") === "production",
                sameSite: "lax",
                path: "/"
            });
        }
        return response;
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
}
const config = {
    matcher: [
        /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */ "/((?!api|_next/static|_next/image|favicon.ico).*)"
    ]
};
}}),
}]);

//# sourceMappingURL=%5Broot-of-the-server%5D__3f3d5ff4._.js.map