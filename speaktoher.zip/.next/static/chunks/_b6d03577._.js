(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/features/checkout/actions/data:f01b0b [app-client] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"78823b9531d66a36c01a9d66e6475fa0e996dc2df1":"attachCustomerToPaymentIntent"},"src/features/checkout/actions/checkoutActions.ts",""] */ __turbopack_context__.s({
    "attachCustomerToPaymentIntent": (()=>attachCustomerToPaymentIntent)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var attachCustomerToPaymentIntent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("78823b9531d66a36c01a9d66e6475fa0e996dc2df1", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "attachCustomerToPaymentIntent"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2hlY2tvdXRBY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiXHJcblxyXG5pbXBvcnQgeyBzdHJpcGVDbGllbnQgfSBmcm9tIFwiQC9saWIvc3RyaXBlL3N0cmlwZUNvbmZpZ1wiXHJcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCJcclxuXHJcbi8qKlxyXG4gKiBJbnB1dCB2YWxpZGF0aW9uIHNjaGVtYSBmb3IgY3VzdG9tZXIgY3JlYXRpb24gYW5kIHBheW1lbnQgaW50ZW50IGF0dGFjaG1lbnRcclxuICovXHJcbmNvbnN0IGNyZWF0ZUN1c3RvbWVyQW5kUGF5bWVudEludGVudFNjaGVtYSA9IHoub2JqZWN0KHtcclxuICBwYXltZW50SW50ZW50SWQ6IHouc3RyaW5nKCkubWluKDEsIFwiUGF5bWVudCBpbnRlbnQgSUQgaXMgcmVxdWlyZWRcIiksXHJcbiAgY3VzdG9tZXJOYW1lOiB6LnN0cmluZygpLm1pbigxLCBcIkN1c3RvbWVyIG5hbWUgaXMgcmVxdWlyZWRcIiksXHJcbiAgY3VzdG9tZXJFbWFpbDogei5zdHJpbmcoKS5lbWFpbChcIkludmFsaWQgZW1haWwgYWRkcmVzc1wiKSxcclxuICBtZXRhZGF0YTogei5yZWNvcmQoei5zdHJpbmcoKSkub3B0aW9uYWwoKSxcclxufSlcclxuXHJcbi8qKlxyXG4gKiBVcGRhdGVzIGFuIGV4aXN0aW5nIHBheW1lbnQgaW50ZW50IHdpdGggY3VzdG9tZXIgaW5mb3JtYXRpb25cclxuICogVXNlIHRoaXMgd2hlbiB5b3UgYWxyZWFkeSBoYXZlIGEgcGF5bWVudCBpbnRlbnQgYnV0IG5lZWQgdG8gYXR0YWNoIGEgY3VzdG9tZXJcclxuICpcclxuICogQHBhcmFtIHBheW1lbnRJbnRlbnRJZCAtIFRoZSBwYXltZW50IGludGVudCBJRCB0byB1cGRhdGVcclxuICogQHBhcmFtIGN1c3RvbWVyTmFtZSAtIEN1c3RvbWVyIG5hbWVcclxuICogQHBhcmFtIGN1c3RvbWVyRW1haWwgLSBDdXN0b21lciBlbWFpbFxyXG4gKiBAcGFyYW0gbWV0YWRhdGEgLSBBZGRpdGlvbmFsIG1ldGFkYXRhXHJcbiAqIEByZXR1cm5zIFByb21pc2U8eyBzdWNjZXNzOiBib29sZWFuOyBlcnJvcj86IHN0cmluZyB9PlxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGF0dGFjaEN1c3RvbWVyVG9QYXltZW50SW50ZW50KFxyXG4gIGNsaWVudFNlY3JldDogc3RyaW5nLFxyXG4gIGN1c3RvbWVyTmFtZTogc3RyaW5nLFxyXG4gIGN1c3RvbWVyRW1haWw6IHN0cmluZyxcclxuICBtZXRhZGF0YT86IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cclxuKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW47IGN1c3RvbWVySWQ/OiBzdHJpbmc7IGVycm9yPzogc3RyaW5nIH0+IHtcclxuICB0cnkge1xyXG4gICAgLy8gQ2hlY2sgaWYgY3VzdG9tZXIgYWxyZWFkeSBleGlzdHNcclxuICAgIGxldCBjdXN0b21lclxyXG4gICAgY29uc3QgZXhpc3RpbmdDdXN0b21lcnMgPSBhd2FpdCBzdHJpcGVDbGllbnQuY3VzdG9tZXJzLmxpc3Qoe1xyXG4gICAgICBlbWFpbDogY3VzdG9tZXJFbWFpbCxcclxuICAgICAgbGltaXQ6IDEsXHJcbiAgICB9KVxyXG5cclxuICAgIGlmIChleGlzdGluZ0N1c3RvbWVycy5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgY3VzdG9tZXIgPSBleGlzdGluZ0N1c3RvbWVycy5kYXRhWzBdXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBDcmVhdGUgbmV3IGN1c3RvbWVyXHJcbiAgICAgIGN1c3RvbWVyID0gYXdhaXQgc3RyaXBlQ2xpZW50LmN1c3RvbWVycy5jcmVhdGUoe1xyXG4gICAgICAgIGVtYWlsOiBjdXN0b21lckVtYWlsLFxyXG4gICAgICAgIG5hbWU6IGN1c3RvbWVyTmFtZSxcclxuXHJcbiAgICAgICAgbWV0YWRhdGE6IHtcclxuICAgICAgICAgIHNvdXJjZTogXCJzcGVha3RvaGVyX2FwcFwiLFxyXG4gICAgICAgICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgLi4ubWV0YWRhdGEsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICAvLyBFeHRyYWN0IHBheW1lbnQgaW50ZW50IElEIGZyb20gY2xpZW50IHNlY3JldFxyXG4gICAgLy8gQ2xpZW50IHNlY3JldCBmb3JtYXQ6IFwicGlfM010d0J3TGtkSXdIdTdpeDI4YTN0cVBhX3NlY3JldF9ZcktKVUtyaWJjQmpjRzhIVmhmWmx1b0dIXCJcclxuICAgIC8vIFBheW1lbnQgaW50ZW50IElEIGlzIHRoZSBwYXJ0IGJlZm9yZSBcIl9zZWNyZXRfXCJcclxuXHJcbiAgICBjb25zdCBwYXltZW50SW50ZW50ID0gY2xpZW50U2VjcmV0LnNwbGl0KFwiX3NlY3JldF9cIilbMF1cclxuICAgIGlmICghcGF5bWVudEludGVudC5zdGFydHNXaXRoKFwicGlfXCIpKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgY2xpZW50IHNlY3JldCBmb3JtYXRcIilcclxuICAgIH1cclxuXHJcbiAgICAvLyBVcGRhdGUgcGF5bWVudCBpbnRlbnQgd2l0aCBjdXN0b21lclxyXG4gICAgYXdhaXQgc3RyaXBlQ2xpZW50LnBheW1lbnRJbnRlbnRzLnVwZGF0ZShwYXltZW50SW50ZW50LCB7XHJcbiAgICAgIGN1c3RvbWVyOiBjdXN0b21lci5pZCxcclxuICAgICAgcmVjZWlwdF9lbWFpbDogY3VzdG9tZXJFbWFpbCxcclxuICAgICAgbWV0YWRhdGE6IHtcclxuICAgICAgICBjdXN0b21lck5hbWUsXHJcbiAgICAgICAgY3VzdG9tZXJFbWFpbCxcclxuICAgICAgICBjdXN0b21lcklkOiBjdXN0b21lci5pZCxcclxuICAgICAgICAuLi5tZXRhZGF0YSxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgY3VzdG9tZXJJZDogY3VzdG9tZXIuaWQgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYXR0YWNoaW5nIGN1c3RvbWVyIHRvIHBheW1lbnQgaW50ZW50OlwiLCBlcnJvcilcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjpcclxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICA/IGVycm9yLm1lc3NhZ2VcclxuICAgICAgICAgIDogXCJGYWlsZWQgdG8gYXR0YWNoIGN1c3RvbWVyIHRvIHBheW1lbnQgaW50ZW50XCIsXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogUmV0cmlldmVzIGN1c3RvbWVyIGluZm9ybWF0aW9uIGJ5IGVtYWlsXHJcbiAqXHJcbiAqIEBwYXJhbSBlbWFpbCAtIEN1c3RvbWVyIGVtYWlsXHJcbiAqIEByZXR1cm5zIFByb21pc2U8eyBzdWNjZXNzOiBib29sZWFuOyBjdXN0b21lcj86IGFueTsgZXJyb3I/OiBzdHJpbmcgfT5cclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDdXN0b21lckJ5RW1haWwoXHJcbiAgZW1haWw6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHsgc3VjY2VzczogYm9vbGVhbjsgY3VzdG9tZXI/OiBhbnk7IGVycm9yPzogc3RyaW5nIH0+IHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY3VzdG9tZXJzID0gYXdhaXQgc3RyaXBlQ2xpZW50LmN1c3RvbWVycy5saXN0KHtcclxuICAgICAgZW1haWw6IGVtYWlsLFxyXG4gICAgICBsaW1pdDogMSxcclxuICAgIH0pXHJcblxyXG4gICAgaWYgKGN1c3RvbWVycy5kYXRhLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBcIkN1c3RvbWVyIG5vdCBmb3VuZFwiLFxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgY3VzdG9tZXI6IGN1c3RvbWVycy5kYXRhWzBdLFxyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmV0cmlldmluZyBjdXN0b21lcjpcIiwgZXJyb3IpXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6XHJcbiAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkZhaWxlZCB0byByZXRyaWV2ZSBjdXN0b21lclwiLFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6InVVQXlCc0IifQ==
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/PaymentForm.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "PaymentForm": (()=>PaymentForm)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@stripe/react-stripe-js/dist/react-stripe.umd.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$checkout$2f$actions$2f$data$3a$f01b0b__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/features/checkout/actions/data:f01b0b [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$TikTokPixelProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/TikTokPixelProvider.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const PaymentForm = ({ clientSecret, onSuccess, onError })=>{
    _s();
    const stripe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStripe"])();
    const elements = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useElements"])();
    const { trackPurchase } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$TikTokPixelProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTikTok"])();
    const [isProcessing, setIsProcessing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [customerName, setCustomerName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [customerEmail, setCustomerEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [whisper, setWhisper] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PaymentForm.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const divineResponse = localStorage.getItem("divineResponse");
                if (divineResponse) {
                    setWhisper(divineResponse);
                }
            }
        }
    }["PaymentForm.useEffect"], []);
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!stripe || !elements) return;
        setIsProcessing(true);
        setMessage(null);
        try {
            const { error: attachCustomerError, customerId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$checkout$2f$actions$2f$data$3a$f01b0b__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["attachCustomerToPaymentIntent"])(clientSecret, customerName, customerEmail);
            if (attachCustomerError) {
                setMessage(attachCustomerError);
                onError?.(attachCustomerError);
                return;
            }
            if (!customerId) {
                setMessage("Failed to create customer profile. Please try again.");
                onError?.("Failed to create customer profile. Please try again.");
                return;
            }
            localStorage.setItem("customerId", customerId);
            localStorage.setItem("customerName", customerName);
            localStorage.setItem("customerEmail", customerEmail);
            // @ts-ignore
            const { error: confirmPaymentError, paymentIntent } = await stripe.confirmPayment({
                elements,
                confirmParams: {
                    return_url: `${window.location.origin}?payment_success=true&customer_id=${customerId}`,
                    payment_method_data: {
                        billing_details: {
                            name: customerName,
                            email: customerEmail
                        }
                    }
                },
                redirect: "always"
            });
            if (confirmPaymentError) {
                const errorMsg = confirmPaymentError.message || "An error occurred during payment";
                setMessage(errorMsg);
                onError?.(errorMsg);
            } else {
                // Track successful purchase
                trackPurchase(9.0, "USD", "divine_message");
            }
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "Payment failed";
            setMessage(errorMessage);
            onError?.(errorMessage);
        } finally{
            setIsProcessing(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-118df89010bc6d8b" + " " + 'w-full max-w-xl mx-auto',
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: "jsx-118df89010bc6d8b" + " " + 'space-y-8 w-full',
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-118df89010bc6d8b" + " " + 'text-center pb-8',
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                style: {
                                    textShadow: "0 0 8px rgba(255, 255, 255, 0.2)",
                                    background: "linear-gradient(135deg, #fff, #a889ff, #fff)",
                                    backgroundSize: "200% 200%",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    backgroundClip: "text",
                                    animation: "shimmer 3s ease-in-out infinite"
                                },
                                className: "jsx-118df89010bc6d8b" + " " + 'text-2xl font-bold text-white',
                                children: "Complete Your Sacred Exchange"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-118df89010bc6d8b" + " " + 'text-sm text-white/70 font-light italic',
                                children: "Receive your divine message in moments"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 121,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-118df89010bc6d8b" + " " + 'flex flex-col gap-6',
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-118df89010bc6d8b",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "name-input",
                                        className: "jsx-118df89010bc6d8b" + " " + 'block text-sm text-center font-medium text-white/90 mb-3',
                                        children: "What name should we attach to your message?"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 129,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        id: "name-input",
                                        value: customerName,
                                        onChange: (e)=>setCustomerName(e.target.value),
                                        placeholder: "Enter your name",
                                        required: true,
                                        autoComplete: "name",
                                        style: {
                                            boxShadow: "0 0 8px rgba(255, 255, 255, 0.1)"
                                        },
                                        className: "jsx-118df89010bc6d8b" + " " + 'w-full px-4 py-3 bg-white/5 border border-white/20 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-400 text-white placeholder-white/40 backdrop-blur-sm text-center'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 134,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-118df89010bc6d8b",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "email-input",
                                        className: "jsx-118df89010bc6d8b" + " " + 'block text-sm text-center font-medium text-white/90 mb-3',
                                        children: "Where should we send your personal message?"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 148,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "email",
                                        id: "email-input",
                                        value: customerEmail,
                                        onChange: (e)=>setCustomerEmail(e.target.value),
                                        placeholder: "Enter your email",
                                        required: true,
                                        autoComplete: "email",
                                        style: {
                                            boxShadow: "0 0 8px rgba(255, 255, 255, 0.1)"
                                        },
                                        className: "jsx-118df89010bc6d8b" + " " + 'w-full px-4 py-3 bg-white/5 border border-white/20 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-400 text-white placeholder-white/40 backdrop-blur-sm text-center'
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 153,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 127,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            paddingTop: "1rem"
                        },
                        className: "jsx-118df89010bc6d8b" + " " + 'space-y-4',
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-118df89010bc6d8b" + " " + 'text-center',
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    style: {
                                        marginBottom: "1rem"
                                    },
                                    className: "jsx-118df89010bc6d8b" + " " + 'text-lg font-medium text-white/90',
                                    children: "✨ Payment Information"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                    lineNumber: 174,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        boxShadow: "0 0 8px rgba(255, 255, 255, 0.1)"
                                    },
                                    className: "jsx-118df89010bc6d8b" + " " + 'bg-white/5 border border-white/20 rounded-lg p-4 backdrop-blur-sm',
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaymentElement"], {
                                        options: {
                                            paymentMethodOrder: [
                                                "card"
                                            ],
                                            layout: {
                                                type: "tabs"
                                            }
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 184,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                    lineNumber: 181,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ui/PaymentForm.tsx",
                            lineNumber: 173,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 168,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-118df89010bc6d8b" + " " + 'pt-6',
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            id: "pay-button",
                            type: "submit",
                            disabled: !stripe || isProcessing,
                            style: {
                                background: "linear-gradient(135deg, #a889ff, #c4b0ff, #a889ff)",
                                backgroundSize: "200% 200%",
                                animation: "gradient-shift 3s ease-in-out infinite",
                                boxShadow: "0 4px 15px rgba(168, 137, 255, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.2)"
                            },
                            className: "jsx-118df89010bc6d8b" + " " + 'w-full text-white py-4 px-6 rounded-lg font-medium shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed relative overflow-hidden',
                            children: isProcessing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "jsx-118df89010bc6d8b" + " " + 'flex items-center justify-center',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        className: "jsx-118df89010bc6d8b" + " " + 'animate-spin -ml-1 mr-3 h-5 w-5 text-white',
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                                cx: "12",
                                                cy: "12",
                                                r: "10",
                                                stroke: "currentColor",
                                                strokeWidth: "4",
                                                className: "jsx-118df89010bc6d8b" + " " + 'opacity-25'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                                lineNumber: 215,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                fill: "currentColor",
                                                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z",
                                                className: "jsx-118df89010bc6d8b" + " " + 'opacity-75'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                                lineNumber: 222,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 210,
                                        columnNumber: 17
                                    }, this),
                                    "Processing divine connection..."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this) : "Complete Payment — $9"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PaymentForm.tsx",
                            lineNumber: 196,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 195,
                        columnNumber: 9
                    }, this),
                    message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-118df89010bc6d8b" + " " + 'text-center',
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "jsx-118df89010bc6d8b" + " " + 'text-red-400 text-sm',
                            children: message
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PaymentForm.tsx",
                            lineNumber: 238,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 237,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-118df89010bc6d8b" + " " + 'text-xs text-white/60 text-center p-4 rounded-lg bg-white/5 border border-white/10 backdrop-blur-sm',
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-118df89010bc6d8b" + " " + 'flex items-center justify-center mb-2',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        className: "jsx-118df89010bc6d8b" + " " + 'w-4 h-4 text-green-400 mr-2',
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            fillRule: "evenodd",
                                            d: "M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z",
                                            clipRule: "evenodd",
                                            className: "jsx-118df89010bc6d8b"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                            lineNumber: 249,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                        lineNumber: 245,
                                        columnNumber: 13
                                    }, this),
                                    "Secure Payment"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 244,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-118df89010bc6d8b" + " " + 'text-white/70',
                                children: "Payments are processed securely by Stripe servers. We do not store any payment information."
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                                lineNumber: 257,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 243,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-118df89010bc6d8b" + " " + 'flex justify-center pt-4',
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "https://images.squarespace-cdn.com/content/v1/64a0699554c0fd6a9b3fdcf4/0b0ac8ad-cb27-4698-8fb1-69b3959fd428/icons_stripe.png",
                            alt: "powered by stripe",
                            className: "jsx-118df89010bc6d8b" + " " + 'w-20 h-auto opacity-50 hover:opacity-70 transition-opacity duration-200'
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/PaymentForm.tsx",
                            lineNumber: 265,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/PaymentForm.tsx",
                        lineNumber: 264,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/PaymentForm.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "118df89010bc6d8b",
                children: "@keyframes shimmer{0%,to{background-position:0%}50%{background-position:100%}}@keyframes gradient-shift{0%,to{background-position:0%}50%{background-position:100%}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/PaymentForm.tsx",
        lineNumber: 104,
        columnNumber: 5
    }, this);
};
_s(PaymentForm, "9bhd/Q/n9WcTAzPFI63R52ctSTc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStripe"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useElements"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$TikTokPixelProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTikTok"]
    ];
});
_c = PaymentForm;
var _c;
__turbopack_context__.k.register(_c, "PaymentForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/Checkout.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Checkout": (()=>Checkout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@stripe/react-stripe-js/dist/react-stripe.umd.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@stripe/stripe-js/lib/index.mjs [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@stripe/stripe-js/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PaymentForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/PaymentForm.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function Checkout({ clientSecret, publishableKey }) {
    _s();
    const [stripePromise, setStripePromise] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Checkout.useEffect": ()=>{
            // Initialize Stripe
            setStripePromise((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$stripe$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadStripe"])(publishableKey));
        }
    }["Checkout.useEffect"], [
        publishableKey
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full flex justify-center items-center px-2",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-screen md:flex md:justify-center md:items-center overflow-y-auto",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: "1.5rem"
                },
                className: "rounded-2xl backdrop-blur-md",
                children: stripePromise && clientSecret && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$stripe$2f$react$2d$stripe$2d$js$2f$dist$2f$react$2d$stripe$2e$umd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Elements"], {
                    stripe: stripePromise,
                    options: {
                        clientSecret,
                        appearance: {
                            theme: "night",
                            variables: {
                                colorPrimary: "#7c3aed",
                                colorBackground: "#1f2937",
                                colorText: "#f3f4f6",
                                colorDanger: "#ef4444",
                                fontFamily: "ui-sans-serif, system-ui, sans-serif",
                                spacingUnit: "4px",
                                borderRadius: "8px"
                            },
                            rules: {
                                ".Tab": {
                                    border: "1px solid #374151",
                                    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)"
                                },
                                ".Tab:hover": {
                                    color: "#7c3aed",
                                    border: "1px solid #7c3aed"
                                },
                                ".Tab--selected": {
                                    border: "1px solid #7c3aed",
                                    boxShadow: "0 0 0 1px #7c3aed"
                                },
                                ".Input": {
                                    border: "1px solid #374151",
                                    backgroundColor: "#1f2937"
                                },
                                ".Input:focus": {
                                    border: "1px solid #7c3aed",
                                    boxShadow: "0 0 0 1px #7c3aed"
                                }
                            }
                        },
                        loader: "always"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$PaymentForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaymentForm"], {
                        clientSecret: clientSecret,
                        onSuccess: (paymentIntent)=>{
                            console.log("Payment successful:", paymentIntent);
                        // Redirect to success page will be handled by Stripe's return_url
                        },
                        onError: (error)=>{
                            console.error("Payment error:", error);
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/Checkout.tsx",
                        lineNumber: 73,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/Checkout.tsx",
                    lineNumber: 31,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/Checkout.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/Checkout.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/Checkout.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(Checkout, "ejXwMGW8CvbPYNT3kExFHC+DaAU=");
_c = Checkout;
var _c;
__turbopack_context__.k.register(_c, "Checkout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/features/home/components/StarsCanvas.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>StarsCanvas)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function StarsCanvas() {
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const starsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StarsCanvas.useEffect": ()=>{
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext("2d");
            if (!ctx) return;
            const resizeCanvas = {
                "StarsCanvas.useEffect.resizeCanvas": ()=>{
                    canvas.width = window.innerWidth;
                    canvas.height = window.innerHeight;
                }
            }["StarsCanvas.useEffect.resizeCanvas"];
            const createStars = {
                "StarsCanvas.useEffect.createStars": ()=>{
                    starsRef.current = [];
                    for(let i = 0; i < 120; i++){
                        starsRef.current.push({
                            x: Math.random() * canvas.width,
                            y: Math.random() * canvas.height,
                            radius: Math.random() * 1.2 + 0.3,
                            speed: Math.random() * 0.5 + 0.2
                        });
                    }
                }
            }["StarsCanvas.useEffect.createStars"];
            const animateStars = {
                "StarsCanvas.useEffect.animateStars": ()=>{
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    for (let star of starsRef.current){
                        ctx.beginPath();
                        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                        ctx.fillStyle = "#ffffffcc";
                        ctx.fill();
                        star.y += star.speed;
                        if (star.y > canvas.height) {
                            star.y = 0;
                            star.x = Math.random() * canvas.width;
                        }
                    }
                    requestAnimationFrame(animateStars);
                }
            }["StarsCanvas.useEffect.animateStars"];
            resizeCanvas();
            createStars();
            animateStars();
            window.addEventListener("resize", resizeCanvas);
            return ({
                "StarsCanvas.useEffect": ()=>window.removeEventListener("resize", resizeCanvas)
            })["StarsCanvas.useEffect"];
        }
    }["StarsCanvas.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
        ref: canvasRef,
        id: "stars"
    }, void 0, false, {
        fileName: "[project]/src/features/home/components/StarsCanvas.tsx",
        lineNumber: 57,
        columnNumber: 10
    }, this);
}
_s(StarsCanvas, "1UxxvqGDCyqK+E67HH70tEHk5Y4=");
_c = StarsCanvas;
var _c;
__turbopack_context__.k.register(_c, "StarsCanvas");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/node_modules/@stripe/react-stripe-js/dist/react-stripe.umd.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
(function(global, factory) {
    ("TURBOPACK compile-time truthy", 1) ? factory(exports, __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)")) : ("TURBOPACK unreachable", undefined);
})(this, function(exports1, React) {
    'use strict';
    function ownKeys(object, enumerableOnly) {
        var keys = Object.keys(object);
        if (Object.getOwnPropertySymbols) {
            var symbols = Object.getOwnPropertySymbols(object);
            if (enumerableOnly) {
                symbols = symbols.filter(function(sym) {
                    return Object.getOwnPropertyDescriptor(object, sym).enumerable;
                });
            }
            keys.push.apply(keys, symbols);
        }
        return keys;
    }
    function _objectSpread2(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i] != null ? arguments[i] : {};
            if (i % 2) {
                ownKeys(Object(source), true).forEach(function(key) {
                    _defineProperty(target, key, source[key]);
                });
            } else if (Object.getOwnPropertyDescriptors) {
                Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
            } else {
                ownKeys(Object(source)).forEach(function(key) {
                    Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
                });
            }
        }
        return target;
    }
    function _typeof(obj) {
        "@babel/helpers - typeof";
        if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
            _typeof = function(obj) {
                return typeof obj;
            };
        } else {
            _typeof = function(obj) {
                return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
            };
        }
        return _typeof(obj);
    }
    function _defineProperty(obj, key, value) {
        if (key in obj) {
            Object.defineProperty(obj, key, {
                value: value,
                enumerable: true,
                configurable: true,
                writable: true
            });
        } else {
            obj[key] = value;
        }
        return obj;
    }
    function _objectWithoutPropertiesLoose(source, excluded) {
        if (source == null) return {};
        var target = {};
        var sourceKeys = Object.keys(source);
        var key, i;
        for(i = 0; i < sourceKeys.length; i++){
            key = sourceKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            target[key] = source[key];
        }
        return target;
    }
    function _objectWithoutProperties(source, excluded) {
        if (source == null) return {};
        var target = _objectWithoutPropertiesLoose(source, excluded);
        var key, i;
        if (Object.getOwnPropertySymbols) {
            var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
            for(i = 0; i < sourceSymbolKeys.length; i++){
                key = sourceSymbolKeys[i];
                if (excluded.indexOf(key) >= 0) continue;
                if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
                target[key] = source[key];
            }
        }
        return target;
    }
    function _slicedToArray(arr, i) {
        return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
    }
    function _arrayWithHoles(arr) {
        if (Array.isArray(arr)) return arr;
    }
    function _iterableToArrayLimit(arr, i) {
        var _i = arr && (typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]);
        if (_i == null) return;
        var _arr = [];
        var _n = true;
        var _d = false;
        var _s, _e;
        try {
            for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
                _arr.push(_s.value);
                if (i && _arr.length === i) break;
            }
        } catch (err) {
            _d = true;
            _e = err;
        } finally{
            try {
                if (!_n && _i["return"] != null) _i["return"]();
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
    function _unsupportedIterableToArray(o, minLen) {
        if (!o) return;
        if (typeof o === "string") return _arrayLikeToArray(o, minLen);
        var n = Object.prototype.toString.call(o).slice(8, -1);
        if (n === "Object" && o.constructor) n = o.constructor.name;
        if (n === "Map" || n === "Set") return Array.from(o);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
    }
    function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length) len = arr.length;
        for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
        return arr2;
    }
    function _nonIterableRest() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function getDefaultExportFromCjs(x) {
        return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
    }
    var propTypes = {
        exports: {}
    };
    /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */ var ReactPropTypesSecret_1;
    var hasRequiredReactPropTypesSecret;
    function requireReactPropTypesSecret() {
        if (hasRequiredReactPropTypesSecret) return ReactPropTypesSecret_1;
        hasRequiredReactPropTypesSecret = 1;
        var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';
        ReactPropTypesSecret_1 = ReactPropTypesSecret;
        return ReactPropTypesSecret_1;
    }
    /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */ var factoryWithThrowingShims;
    var hasRequiredFactoryWithThrowingShims;
    function requireFactoryWithThrowingShims() {
        if (hasRequiredFactoryWithThrowingShims) return factoryWithThrowingShims;
        hasRequiredFactoryWithThrowingShims = 1;
        var ReactPropTypesSecret = requireReactPropTypesSecret();
        function emptyFunction() {}
        function emptyFunctionWithReset() {}
        emptyFunctionWithReset.resetWarningCache = emptyFunction;
        factoryWithThrowingShims = function() {
            function shim(props, propName, componentName, location, propFullName, secret) {
                if (secret === ReactPropTypesSecret) {
                    // It is still safe when called from React.
                    return;
                }
                var err = new Error('Calling PropTypes validators directly is not supported by the `prop-types` package. ' + 'Use PropTypes.checkPropTypes() to call them. ' + 'Read more at http://fb.me/use-check-prop-types');
                err.name = 'Invariant Violation';
                throw err;
            }
            shim.isRequired = shim;
            function getShim() {
                return shim;
            }
            // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
            var ReactPropTypes = {
                array: shim,
                bool: shim,
                func: shim,
                number: shim,
                object: shim,
                string: shim,
                symbol: shim,
                any: shim,
                arrayOf: getShim,
                element: shim,
                elementType: shim,
                instanceOf: getShim,
                node: shim,
                objectOf: getShim,
                oneOf: getShim,
                oneOfType: getShim,
                shape: getShim,
                exact: getShim,
                checkPropTypes: emptyFunctionWithReset,
                resetWarningCache: emptyFunction
            };
            ReactPropTypes.PropTypes = ReactPropTypes;
            return ReactPropTypes;
        };
        return factoryWithThrowingShims;
    }
    /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */ {
        // By explicitly using `prop-types` you are opting into new production behavior.
        // http://fb.me/prop-types-in-prod
        propTypes.exports = requireFactoryWithThrowingShims()();
    }
    var propTypesExports = propTypes.exports;
    var PropTypes = /*@__PURE__*/ getDefaultExportFromCjs(propTypesExports);
    var useAttachEvent = function useAttachEvent(element, event, cb) {
        var cbDefined = !!cb;
        var cbRef = React.useRef(cb); // In many integrations the callback prop changes on each render.
        // Using a ref saves us from calling element.on/.off every render.
        React.useEffect({
            "useAttachEvent.useEffect": function() {
                cbRef.current = cb;
            }
        }["useAttachEvent.useEffect"], [
            cb
        ]);
        React.useEffect({
            "useAttachEvent.useEffect": function() {
                if (!cbDefined || !element) {
                    return ({
                        "useAttachEvent.useEffect": function() {}
                    })["useAttachEvent.useEffect"];
                }
                var decoratedCb = function decoratedCb() {
                    if (cbRef.current) {
                        cbRef.current.apply(cbRef, arguments);
                    }
                };
                element.on(event, decoratedCb);
                return ({
                    "useAttachEvent.useEffect": function() {
                        element.off(event, decoratedCb);
                    }
                })["useAttachEvent.useEffect"];
            }
        }["useAttachEvent.useEffect"], [
            cbDefined,
            event,
            element,
            cbRef
        ]);
    };
    var usePrevious = function usePrevious(value) {
        var ref = React.useRef(value);
        React.useEffect({
            "usePrevious.useEffect": function() {
                ref.current = value;
            }
        }["usePrevious.useEffect"], [
            value
        ]);
        return ref.current;
    };
    var isUnknownObject = function isUnknownObject(raw) {
        return raw !== null && _typeof(raw) === 'object';
    };
    var isPromise = function isPromise(raw) {
        return isUnknownObject(raw) && typeof raw.then === 'function';
    }; // We are using types to enforce the `stripe` prop in this lib,
    // but in an untyped integration `stripe` could be anything, so we need
    // to do some sanity validation to prevent type errors.
    var isStripe = function isStripe(raw) {
        return isUnknownObject(raw) && typeof raw.elements === 'function' && typeof raw.createToken === 'function' && typeof raw.createPaymentMethod === 'function' && typeof raw.confirmCardPayment === 'function';
    };
    var PLAIN_OBJECT_STR = '[object Object]';
    var isEqual = function isEqual(left, right) {
        if (!isUnknownObject(left) || !isUnknownObject(right)) {
            return left === right;
        }
        var leftArray = Array.isArray(left);
        var rightArray = Array.isArray(right);
        if (leftArray !== rightArray) return false;
        var leftPlainObject = Object.prototype.toString.call(left) === PLAIN_OBJECT_STR;
        var rightPlainObject = Object.prototype.toString.call(right) === PLAIN_OBJECT_STR;
        if (leftPlainObject !== rightPlainObject) return false; // not sure what sort of special object this is (regexp is one option), so
        // fallback to reference check.
        if (!leftPlainObject && !leftArray) return left === right;
        var leftKeys = Object.keys(left);
        var rightKeys = Object.keys(right);
        if (leftKeys.length !== rightKeys.length) return false;
        var keySet = {};
        for(var i = 0; i < leftKeys.length; i += 1){
            keySet[leftKeys[i]] = true;
        }
        for(var _i = 0; _i < rightKeys.length; _i += 1){
            keySet[rightKeys[_i]] = true;
        }
        var allKeys = Object.keys(keySet);
        if (allKeys.length !== leftKeys.length) {
            return false;
        }
        var l = left;
        var r = right;
        var pred = function pred(key) {
            return isEqual(l[key], r[key]);
        };
        return allKeys.every(pred);
    };
    var extractAllowedOptionsUpdates = function extractAllowedOptionsUpdates(options, prevOptions, immutableKeys) {
        if (!isUnknownObject(options)) {
            return null;
        }
        return Object.keys(options).reduce(function(newOptions, key) {
            var isUpdated = !isUnknownObject(prevOptions) || !isEqual(options[key], prevOptions[key]);
            if (immutableKeys.includes(key)) {
                if (isUpdated) {
                    console.warn("Unsupported prop change: options.".concat(key, " is not a mutable property."));
                }
                return newOptions;
            }
            if (!isUpdated) {
                return newOptions;
            }
            return _objectSpread2(_objectSpread2({}, newOptions || {}), {}, _defineProperty({}, key, options[key]));
        }, null);
    };
    var INVALID_STRIPE_ERROR$2 = 'Invalid prop `stripe` supplied to `Elements`. We recommend using the `loadStripe` utility from `@stripe/stripe-js`. See https://stripe.com/docs/stripe-js/react#elements-props-stripe for details.'; // We are using types to enforce the `stripe` prop in this lib, but in a real
    // integration `stripe` could be anything, so we need to do some sanity
    // validation to prevent type errors.
    var validateStripe = function validateStripe(maybeStripe) {
        var errorMsg = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : INVALID_STRIPE_ERROR$2;
        if (maybeStripe === null || isStripe(maybeStripe)) {
            return maybeStripe;
        }
        throw new Error(errorMsg);
    };
    var parseStripeProp = function parseStripeProp(raw) {
        var errorMsg = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : INVALID_STRIPE_ERROR$2;
        if (isPromise(raw)) {
            return {
                tag: 'async',
                stripePromise: Promise.resolve(raw).then(function(result) {
                    return validateStripe(result, errorMsg);
                })
            };
        }
        var stripe = validateStripe(raw, errorMsg);
        if (stripe === null) {
            return {
                tag: 'empty'
            };
        }
        return {
            tag: 'sync',
            stripe: stripe
        };
    };
    var registerWithStripeJs = function registerWithStripeJs(stripe) {
        if (!stripe || !stripe._registerWrapper || !stripe.registerAppInfo) {
            return;
        }
        stripe._registerWrapper({
            name: 'react-stripe-js',
            version: "3.7.0"
        });
        stripe.registerAppInfo({
            name: 'react-stripe-js',
            version: "3.7.0",
            url: 'https://stripe.com/docs/stripe-js/react'
        });
    };
    var ElementsContext = /*#__PURE__*/ React.createContext(null);
    ElementsContext.displayName = 'ElementsContext';
    var parseElementsContext = function parseElementsContext(ctx, useCase) {
        if (!ctx) {
            throw new Error("Could not find Elements context; You need to wrap the part of your app that ".concat(useCase, " in an <Elements> provider."));
        }
        return ctx;
    };
    /**
   * The `Elements` provider allows you to use [Element components](https://stripe.com/docs/stripe-js/react#element-components) and access the [Stripe object](https://stripe.com/docs/js/initializing) in any nested component.
   * Render an `Elements` provider at the root of your React app so that it is available everywhere you need it.
   *
   * To use the `Elements` provider, call `loadStripe` from `@stripe/stripe-js` with your publishable key.
   * The `loadStripe` function will asynchronously load the Stripe.js script and initialize a `Stripe` object.
   * Pass the returned `Promise` to `Elements`.
   *
   * @docs https://stripe.com/docs/stripe-js/react#elements-provider
   */ var Elements = function Elements(_ref) {
        var rawStripeProp = _ref.stripe, options = _ref.options, children = _ref.children;
        var parsed = React.useMemo({
            "Elements.useMemo[parsed]": function() {
                return parseStripeProp(rawStripeProp);
            }
        }["Elements.useMemo[parsed]"], [
            rawStripeProp
        ]); // For a sync stripe instance, initialize into context
        var _React$useState = React.useState({
            "Elements.useState[_React$useState]": function() {
                return {
                    stripe: parsed.tag === 'sync' ? parsed.stripe : null,
                    elements: parsed.tag === 'sync' ? parsed.stripe.elements(options) : null
                };
            }
        }["Elements.useState[_React$useState]"]), _React$useState2 = _slicedToArray(_React$useState, 2), ctx = _React$useState2[0], setContext = _React$useState2[1];
        React.useEffect({
            "Elements.useEffect": function() {
                var isMounted = true;
                var safeSetContext = function safeSetContext(stripe) {
                    setContext({
                        "Elements.useEffect.safeSetContext": function(ctx) {
                            // no-op if we already have a stripe instance (https://github.com/stripe/react-stripe-js/issues/296)
                            if (ctx.stripe) return ctx;
                            return {
                                stripe: stripe,
                                elements: stripe.elements(options)
                            };
                        }
                    }["Elements.useEffect.safeSetContext"]);
                }; // For an async stripePromise, store it in context once resolved
                if (parsed.tag === 'async' && !ctx.stripe) {
                    parsed.stripePromise.then({
                        "Elements.useEffect": function(stripe) {
                            if (stripe && isMounted) {
                                // Only update Elements context if the component is still mounted
                                // and stripe is not null. We allow stripe to be null to make
                                // handling SSR easier.
                                safeSetContext(stripe);
                            }
                        }
                    }["Elements.useEffect"]);
                } else if (parsed.tag === 'sync' && !ctx.stripe) {
                    // Or, handle a sync stripe instance going from null -> populated
                    safeSetContext(parsed.stripe);
                }
                return ({
                    "Elements.useEffect": function() {
                        isMounted = false;
                    }
                })["Elements.useEffect"];
            }
        }["Elements.useEffect"], [
            parsed,
            ctx,
            options
        ]); // Warn on changes to stripe prop
        var prevStripe = usePrevious(rawStripeProp);
        React.useEffect({
            "Elements.useEffect": function() {
                if (prevStripe !== null && prevStripe !== rawStripeProp) {
                    console.warn('Unsupported prop change on Elements: You cannot change the `stripe` prop after setting it.');
                }
            }
        }["Elements.useEffect"], [
            prevStripe,
            rawStripeProp
        ]); // Apply updates to elements when options prop has relevant changes
        var prevOptions = usePrevious(options);
        React.useEffect({
            "Elements.useEffect": function() {
                if (!ctx.elements) {
                    return;
                }
                var updates = extractAllowedOptionsUpdates(options, prevOptions, [
                    'clientSecret',
                    'fonts'
                ]);
                if (updates) {
                    ctx.elements.update(updates);
                }
            }
        }["Elements.useEffect"], [
            options,
            prevOptions,
            ctx.elements
        ]); // Attach react-stripe-js version to stripe.js instance
        React.useEffect({
            "Elements.useEffect": function() {
                registerWithStripeJs(ctx.stripe);
            }
        }["Elements.useEffect"], [
            ctx.stripe
        ]);
        return /*#__PURE__*/ React.createElement(ElementsContext.Provider, {
            value: ctx
        }, children);
    };
    Elements.propTypes = {
        stripe: PropTypes.any,
        options: PropTypes.object
    };
    var useElementsContextWithUseCase = function useElementsContextWithUseCase(useCaseMessage) {
        var ctx = React.useContext(ElementsContext);
        return parseElementsContext(ctx, useCaseMessage);
    };
    /**
   * @docs https://stripe.com/docs/stripe-js/react#useelements-hook
   */ var useElements = function useElements() {
        var _useElementsContextWi = useElementsContextWithUseCase('calls useElements()'), elements = _useElementsContextWi.elements;
        return elements;
    };
    /**
   * @docs https://stripe.com/docs/stripe-js/react#elements-consumer
   */ var ElementsConsumer = function ElementsConsumer(_ref2) {
        var children = _ref2.children;
        var ctx = useElementsContextWithUseCase('mounts <ElementsConsumer>'); // Assert to satisfy the busted React.FC return type (it should be ReactNode)
        return children(ctx);
    };
    ElementsConsumer.propTypes = {
        children: PropTypes.func.isRequired
    };
    var _excluded$1 = [
        "on",
        "session"
    ];
    var CheckoutSdkContext = /*#__PURE__*/ React.createContext(null);
    CheckoutSdkContext.displayName = 'CheckoutSdkContext';
    var parseCheckoutSdkContext = function parseCheckoutSdkContext(ctx, useCase) {
        if (!ctx) {
            throw new Error("Could not find CheckoutProvider context; You need to wrap the part of your app that ".concat(useCase, " in an <CheckoutProvider> provider."));
        }
        return ctx;
    };
    var CheckoutContext = /*#__PURE__*/ React.createContext(null);
    CheckoutContext.displayName = 'CheckoutContext';
    var extractCheckoutContextValue = function extractCheckoutContextValue(checkoutSdk, sessionState) {
        if (!checkoutSdk) {
            return null;
        }
        checkoutSdk.on;
        checkoutSdk.session;
        var actions = _objectWithoutProperties(checkoutSdk, _excluded$1);
        if (!sessionState) {
            return Object.assign(checkoutSdk.session(), actions);
        }
        return Object.assign(sessionState, actions);
    };
    var INVALID_STRIPE_ERROR$1 = 'Invalid prop `stripe` supplied to `CheckoutProvider`. We recommend using the `loadStripe` utility from `@stripe/stripe-js`. See https://stripe.com/docs/stripe-js/react#elements-props-stripe for details.';
    var CheckoutProvider = function CheckoutProvider(_ref) {
        var rawStripeProp = _ref.stripe, options = _ref.options, children = _ref.children;
        var parsed = React.useMemo({
            "CheckoutProvider.useMemo[parsed]": function() {
                return parseStripeProp(rawStripeProp, INVALID_STRIPE_ERROR$1);
            }
        }["CheckoutProvider.useMemo[parsed]"], [
            rawStripeProp
        ]); // State used to trigger a re-render when sdk.session is updated
        var _React$useState = React.useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), session = _React$useState2[0], setSession = _React$useState2[1];
        var _React$useState3 = React.useState({
            "CheckoutProvider.useState[_React$useState3]": function() {
                return {
                    stripe: parsed.tag === 'sync' ? parsed.stripe : null,
                    checkoutSdk: null
                };
            }
        }["CheckoutProvider.useState[_React$useState3]"]), _React$useState4 = _slicedToArray(_React$useState3, 2), ctx = _React$useState4[0], setContext = _React$useState4[1];
        var safeSetContext = function safeSetContext(stripe, checkoutSdk) {
            setContext(function(ctx) {
                if (ctx.stripe && ctx.checkoutSdk) {
                    return ctx;
                }
                return {
                    stripe: stripe,
                    checkoutSdk: checkoutSdk
                };
            });
        }; // Ref used to avoid calling initCheckout multiple times when options changes
        var initCheckoutCalledRef = React.useRef(false);
        React.useEffect({
            "CheckoutProvider.useEffect": function() {
                var isMounted = true;
                if (parsed.tag === 'async' && !ctx.stripe) {
                    parsed.stripePromise.then({
                        "CheckoutProvider.useEffect": function(stripe) {
                            if (stripe && isMounted && !initCheckoutCalledRef.current) {
                                // Only update context if the component is still mounted
                                // and stripe is not null. We allow stripe to be null to make
                                // handling SSR easier.
                                initCheckoutCalledRef.current = true;
                                stripe.initCheckout(options).then({
                                    "CheckoutProvider.useEffect": function(checkoutSdk) {
                                        if (checkoutSdk) {
                                            safeSetContext(stripe, checkoutSdk);
                                            checkoutSdk.on('change', setSession);
                                        }
                                    }
                                }["CheckoutProvider.useEffect"]);
                            }
                        }
                    }["CheckoutProvider.useEffect"]);
                } else if (parsed.tag === 'sync' && parsed.stripe && !initCheckoutCalledRef.current) {
                    initCheckoutCalledRef.current = true;
                    parsed.stripe.initCheckout(options).then({
                        "CheckoutProvider.useEffect": function(checkoutSdk) {
                            if (checkoutSdk) {
                                safeSetContext(parsed.stripe, checkoutSdk);
                                checkoutSdk.on('change', setSession);
                            }
                        }
                    }["CheckoutProvider.useEffect"]);
                }
                return ({
                    "CheckoutProvider.useEffect": function() {
                        isMounted = false;
                    }
                })["CheckoutProvider.useEffect"];
            }
        }["CheckoutProvider.useEffect"], [
            parsed,
            ctx,
            options,
            setSession
        ]); // Warn on changes to stripe prop
        var prevStripe = usePrevious(rawStripeProp);
        React.useEffect({
            "CheckoutProvider.useEffect": function() {
                if (prevStripe !== null && prevStripe !== rawStripeProp) {
                    console.warn('Unsupported prop change on CheckoutProvider: You cannot change the `stripe` prop after setting it.');
                }
            }
        }["CheckoutProvider.useEffect"], [
            prevStripe,
            rawStripeProp
        ]); // Apply updates to elements when options prop has relevant changes
        var prevOptions = usePrevious(options);
        var prevCheckoutSdk = usePrevious(ctx.checkoutSdk);
        React.useEffect({
            "CheckoutProvider.useEffect": function() {
                var _prevOptions$elements, _options$elementsOpti;
                // Ignore changes while checkout sdk is not initialized.
                if (!ctx.checkoutSdk) {
                    return;
                }
                var previousAppearance = prevOptions === null || prevOptions === void 0 ? void 0 : (_prevOptions$elements = prevOptions.elementsOptions) === null || _prevOptions$elements === void 0 ? void 0 : _prevOptions$elements.appearance;
                var currentAppearance = options === null || options === void 0 ? void 0 : (_options$elementsOpti = options.elementsOptions) === null || _options$elementsOpti === void 0 ? void 0 : _options$elementsOpti.appearance;
                var hasAppearanceChanged = !isEqual(currentAppearance, previousAppearance);
                var hasSdkLoaded = !prevCheckoutSdk && ctx.checkoutSdk;
                if (currentAppearance && (hasAppearanceChanged || hasSdkLoaded)) {
                    ctx.checkoutSdk.changeAppearance(currentAppearance);
                }
            }
        }["CheckoutProvider.useEffect"], [
            options,
            prevOptions,
            ctx.checkoutSdk,
            prevCheckoutSdk
        ]); // Attach react-stripe-js version to stripe.js instance
        React.useEffect({
            "CheckoutProvider.useEffect": function() {
                registerWithStripeJs(ctx.stripe);
            }
        }["CheckoutProvider.useEffect"], [
            ctx.stripe
        ]);
        var checkoutContextValue = React.useMemo({
            "CheckoutProvider.useMemo[checkoutContextValue]": function() {
                return extractCheckoutContextValue(ctx.checkoutSdk, session);
            }
        }["CheckoutProvider.useMemo[checkoutContextValue]"], [
            ctx.checkoutSdk,
            session
        ]);
        if (!ctx.checkoutSdk) {
            return null;
        }
        return /*#__PURE__*/ React.createElement(CheckoutSdkContext.Provider, {
            value: ctx
        }, /*#__PURE__*/ React.createElement(CheckoutContext.Provider, {
            value: checkoutContextValue
        }, children));
    };
    CheckoutProvider.propTypes = {
        stripe: PropTypes.any,
        options: PropTypes.shape({
            fetchClientSecret: PropTypes.func.isRequired,
            elementsOptions: PropTypes.object
        }).isRequired
    };
    var useCheckoutSdkContextWithUseCase = function useCheckoutSdkContextWithUseCase(useCaseString) {
        var ctx = React.useContext(CheckoutSdkContext);
        return parseCheckoutSdkContext(ctx, useCaseString);
    };
    var useElementsOrCheckoutSdkContextWithUseCase = function useElementsOrCheckoutSdkContextWithUseCase(useCaseString) {
        var checkoutSdkContext = React.useContext(CheckoutSdkContext);
        var elementsContext = React.useContext(ElementsContext);
        if (checkoutSdkContext && elementsContext) {
            throw new Error("You cannot wrap the part of your app that ".concat(useCaseString, " in both <CheckoutProvider> and <Elements> providers."));
        }
        if (checkoutSdkContext) {
            return parseCheckoutSdkContext(checkoutSdkContext, useCaseString);
        }
        return parseElementsContext(elementsContext, useCaseString);
    };
    var useCheckout = function useCheckout() {
        // ensure it's in CheckoutProvider
        useCheckoutSdkContextWithUseCase('calls useCheckout()');
        var ctx = React.useContext(CheckoutContext);
        if (!ctx) {
            throw new Error('Could not find Checkout Context; You need to wrap the part of your app that calls useCheckout() in an <CheckoutProvider> provider.');
        }
        return ctx;
    };
    var _excluded = [
        "mode"
    ];
    var capitalized = function capitalized(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    };
    var createElementComponent = function createElementComponent(type, isServer) {
        var displayName = "".concat(capitalized(type), "Element");
        var ClientElement = function ClientElement(_ref) {
            var id = _ref.id, className = _ref.className, _ref$options = _ref.options, options = _ref$options === void 0 ? {} : _ref$options, onBlur = _ref.onBlur, onFocus = _ref.onFocus, onReady = _ref.onReady, onChange = _ref.onChange, onEscape = _ref.onEscape, onClick = _ref.onClick, onLoadError = _ref.onLoadError, onLoaderStart = _ref.onLoaderStart, onNetworksChange = _ref.onNetworksChange, onConfirm = _ref.onConfirm, onCancel = _ref.onCancel, onShippingAddressChange = _ref.onShippingAddressChange, onShippingRateChange = _ref.onShippingRateChange;
            var ctx = useElementsOrCheckoutSdkContextWithUseCase("mounts <".concat(displayName, ">"));
            var elements = 'elements' in ctx ? ctx.elements : null;
            var checkoutSdk = 'checkoutSdk' in ctx ? ctx.checkoutSdk : null;
            var _React$useState = React.useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), element = _React$useState2[0], setElement = _React$useState2[1];
            var elementRef = React.useRef(null);
            var domNode = React.useRef(null); // For every event where the merchant provides a callback, call element.on
            // with that callback. If the merchant ever changes the callback, removes
            // the old callback with element.off and then call element.on with the new one.
            useAttachEvent(element, 'blur', onBlur);
            useAttachEvent(element, 'focus', onFocus);
            useAttachEvent(element, 'escape', onEscape);
            useAttachEvent(element, 'click', onClick);
            useAttachEvent(element, 'loaderror', onLoadError);
            useAttachEvent(element, 'loaderstart', onLoaderStart);
            useAttachEvent(element, 'networkschange', onNetworksChange);
            useAttachEvent(element, 'confirm', onConfirm);
            useAttachEvent(element, 'cancel', onCancel);
            useAttachEvent(element, 'shippingaddresschange', onShippingAddressChange);
            useAttachEvent(element, 'shippingratechange', onShippingRateChange);
            useAttachEvent(element, 'change', onChange);
            var readyCallback;
            if (onReady) {
                if (type === 'expressCheckout') {
                    // Passes through the event, which includes visible PM types
                    readyCallback = onReady;
                } else {
                    // For other Elements, pass through the Element itself.
                    readyCallback = function readyCallback() {
                        onReady(element);
                    };
                }
            }
            useAttachEvent(element, 'ready', readyCallback);
            React.useLayoutEffect({
                "createElementComponent.ClientElement.useLayoutEffect": function() {
                    if (elementRef.current === null && domNode.current !== null && (elements || checkoutSdk)) {
                        var newElement = null;
                        if (checkoutSdk) {
                            switch(type){
                                case 'payment':
                                    newElement = checkoutSdk.createPaymentElement(options);
                                    break;
                                case 'address':
                                    if ('mode' in options) {
                                        var mode = options.mode, restOptions = _objectWithoutProperties(options, _excluded);
                                        if (mode === 'shipping') {
                                            newElement = checkoutSdk.createShippingAddressElement(restOptions);
                                        } else if (mode === 'billing') {
                                            newElement = checkoutSdk.createBillingAddressElement(restOptions);
                                        } else {
                                            throw new Error("Invalid options.mode. mode must be 'billing' or 'shipping'.");
                                        }
                                    } else {
                                        throw new Error("You must supply options.mode. mode must be 'billing' or 'shipping'.");
                                    }
                                    break;
                                case 'expressCheckout':
                                    newElement = checkoutSdk.createExpressCheckoutElement(options);
                                    break;
                                case 'currencySelector':
                                    newElement = checkoutSdk.createCurrencySelectorElement();
                                    break;
                                default:
                                    throw new Error("Invalid Element type ".concat(displayName, ". You must use either the <PaymentElement />, <AddressElement options={{mode: 'shipping'}} />, <AddressElement options={{mode: 'billing'}} />, or <ExpressCheckoutElement />."));
                            }
                        } else if (elements) {
                            newElement = elements.create(type, options);
                        } // Store element in a ref to ensure it's _immediately_ available in cleanup hooks in StrictMode
                        elementRef.current = newElement; // Store element in state to facilitate event listener attachment
                        setElement(newElement);
                        if (newElement) {
                            newElement.mount(domNode.current);
                        }
                    }
                }
            }["createElementComponent.ClientElement.useLayoutEffect"], [
                elements,
                checkoutSdk,
                options
            ]);
            var prevOptions = usePrevious(options);
            React.useEffect({
                "createElementComponent.ClientElement.useEffect": function() {
                    if (!elementRef.current) {
                        return;
                    }
                    var updates = extractAllowedOptionsUpdates(options, prevOptions, [
                        'paymentRequest'
                    ]);
                    if (updates && 'update' in elementRef.current) {
                        elementRef.current.update(updates);
                    }
                }
            }["createElementComponent.ClientElement.useEffect"], [
                options,
                prevOptions
            ]);
            React.useLayoutEffect({
                "createElementComponent.ClientElement.useLayoutEffect": function() {
                    return ({
                        "createElementComponent.ClientElement.useLayoutEffect": function() {
                            if (elementRef.current && typeof elementRef.current.destroy === 'function') {
                                try {
                                    elementRef.current.destroy();
                                    elementRef.current = null;
                                } catch (error) {}
                            }
                        }
                    })["createElementComponent.ClientElement.useLayoutEffect"];
                }
            }["createElementComponent.ClientElement.useLayoutEffect"], []);
            return /*#__PURE__*/ React.createElement("div", {
                id: id,
                className: className,
                ref: domNode
            });
        }; // Only render the Element wrapper in a server environment.
        var ServerElement = function ServerElement(props) {
            useElementsOrCheckoutSdkContextWithUseCase("mounts <".concat(displayName, ">"));
            var id = props.id, className = props.className;
            return /*#__PURE__*/ React.createElement("div", {
                id: id,
                className: className
            });
        };
        var Element = isServer ? ServerElement : ClientElement;
        Element.propTypes = {
            id: PropTypes.string,
            className: PropTypes.string,
            onChange: PropTypes.func,
            onBlur: PropTypes.func,
            onFocus: PropTypes.func,
            onReady: PropTypes.func,
            onEscape: PropTypes.func,
            onClick: PropTypes.func,
            onLoadError: PropTypes.func,
            onLoaderStart: PropTypes.func,
            onNetworksChange: PropTypes.func,
            onConfirm: PropTypes.func,
            onCancel: PropTypes.func,
            onShippingAddressChange: PropTypes.func,
            onShippingRateChange: PropTypes.func,
            options: PropTypes.object
        };
        Element.displayName = displayName;
        Element.__elementType = type;
        return Element;
    };
    var isServer = typeof window === 'undefined';
    var EmbeddedCheckoutContext = /*#__PURE__*/ React.createContext(null);
    EmbeddedCheckoutContext.displayName = 'EmbeddedCheckoutProviderContext';
    var useEmbeddedCheckoutContext = function useEmbeddedCheckoutContext() {
        var ctx = React.useContext(EmbeddedCheckoutContext);
        if (!ctx) {
            throw new Error('<EmbeddedCheckout> must be used within <EmbeddedCheckoutProvider>');
        }
        return ctx;
    };
    var INVALID_STRIPE_ERROR = 'Invalid prop `stripe` supplied to `EmbeddedCheckoutProvider`. We recommend using the `loadStripe` utility from `@stripe/stripe-js`. See https://stripe.com/docs/stripe-js/react#elements-props-stripe for details.';
    var EmbeddedCheckoutProvider = function EmbeddedCheckoutProvider(_ref) {
        var rawStripeProp = _ref.stripe, options = _ref.options, children = _ref.children;
        var parsed = React.useMemo({
            "EmbeddedCheckoutProvider.useMemo[parsed]": function() {
                return parseStripeProp(rawStripeProp, INVALID_STRIPE_ERROR);
            }
        }["EmbeddedCheckoutProvider.useMemo[parsed]"], [
            rawStripeProp
        ]);
        var embeddedCheckoutPromise = React.useRef(null);
        var loadedStripe = React.useRef(null);
        var _React$useState = React.useState({
            embeddedCheckout: null
        }), _React$useState2 = _slicedToArray(_React$useState, 2), ctx = _React$useState2[0], setContext = _React$useState2[1];
        React.useEffect({
            "EmbeddedCheckoutProvider.useEffect": function() {
                // Don't support any ctx updates once embeddedCheckout or stripe is set.
                if (loadedStripe.current || embeddedCheckoutPromise.current) {
                    return;
                }
                var setStripeAndInitEmbeddedCheckout = function setStripeAndInitEmbeddedCheckout(stripe) {
                    if (loadedStripe.current || embeddedCheckoutPromise.current) return;
                    loadedStripe.current = stripe;
                    embeddedCheckoutPromise.current = loadedStripe.current.initEmbeddedCheckout(options).then({
                        "EmbeddedCheckoutProvider.useEffect.setStripeAndInitEmbeddedCheckout": function(embeddedCheckout) {
                            setContext({
                                embeddedCheckout: embeddedCheckout
                            });
                        }
                    }["EmbeddedCheckoutProvider.useEffect.setStripeAndInitEmbeddedCheckout"]);
                }; // For an async stripePromise, store it once resolved
                if (parsed.tag === 'async' && !loadedStripe.current && (options.clientSecret || options.fetchClientSecret)) {
                    parsed.stripePromise.then({
                        "EmbeddedCheckoutProvider.useEffect": function(stripe) {
                            if (stripe) {
                                setStripeAndInitEmbeddedCheckout(stripe);
                            }
                        }
                    }["EmbeddedCheckoutProvider.useEffect"]);
                } else if (parsed.tag === 'sync' && !loadedStripe.current && (options.clientSecret || options.fetchClientSecret)) {
                    // Or, handle a sync stripe instance going from null -> populated
                    setStripeAndInitEmbeddedCheckout(parsed.stripe);
                }
            }
        }["EmbeddedCheckoutProvider.useEffect"], [
            parsed,
            options,
            ctx,
            loadedStripe
        ]);
        React.useEffect({
            "EmbeddedCheckoutProvider.useEffect": function() {
                // cleanup on unmount
                return ({
                    "EmbeddedCheckoutProvider.useEffect": function() {
                        // If embedded checkout is fully initialized, destroy it.
                        if (ctx.embeddedCheckout) {
                            embeddedCheckoutPromise.current = null;
                            ctx.embeddedCheckout.destroy();
                        } else if (embeddedCheckoutPromise.current) {
                            // If embedded checkout is still initializing, destroy it once
                            // it's done. This could be caused by unmounting very quickly
                            // after mounting.
                            embeddedCheckoutPromise.current.then({
                                "EmbeddedCheckoutProvider.useEffect": function() {
                                    embeddedCheckoutPromise.current = null;
                                    if (ctx.embeddedCheckout) {
                                        ctx.embeddedCheckout.destroy();
                                    }
                                }
                            }["EmbeddedCheckoutProvider.useEffect"]);
                        }
                    }
                })["EmbeddedCheckoutProvider.useEffect"];
            }
        }["EmbeddedCheckoutProvider.useEffect"], [
            ctx.embeddedCheckout
        ]); // Attach react-stripe-js version to stripe.js instance
        React.useEffect({
            "EmbeddedCheckoutProvider.useEffect": function() {
                registerWithStripeJs(loadedStripe);
            }
        }["EmbeddedCheckoutProvider.useEffect"], [
            loadedStripe
        ]); // Warn on changes to stripe prop.
        // The stripe prop value can only go from null to non-null once and
        // can't be changed after that.
        var prevStripe = usePrevious(rawStripeProp);
        React.useEffect({
            "EmbeddedCheckoutProvider.useEffect": function() {
                if (prevStripe !== null && prevStripe !== rawStripeProp) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot change the `stripe` prop after setting it.');
                }
            }
        }["EmbeddedCheckoutProvider.useEffect"], [
            prevStripe,
            rawStripeProp
        ]); // Warn on changes to options.
        var prevOptions = usePrevious(options);
        React.useEffect({
            "EmbeddedCheckoutProvider.useEffect": function() {
                if (prevOptions == null) {
                    return;
                }
                if (options == null) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot unset options after setting them.');
                    return;
                }
                if (options.clientSecret === undefined && options.fetchClientSecret === undefined) {
                    console.warn('Invalid props passed to EmbeddedCheckoutProvider: You must provide one of either `options.fetchClientSecret` or `options.clientSecret`.');
                }
                if (prevOptions.clientSecret != null && options.clientSecret !== prevOptions.clientSecret) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot change the client secret after setting it. Unmount and create a new instance of EmbeddedCheckoutProvider instead.');
                }
                if (prevOptions.fetchClientSecret != null && options.fetchClientSecret !== prevOptions.fetchClientSecret) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot change fetchClientSecret after setting it. Unmount and create a new instance of EmbeddedCheckoutProvider instead.');
                }
                if (prevOptions.onComplete != null && options.onComplete !== prevOptions.onComplete) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot change the onComplete option after setting it.');
                }
                if (prevOptions.onShippingDetailsChange != null && options.onShippingDetailsChange !== prevOptions.onShippingDetailsChange) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot change the onShippingDetailsChange option after setting it.');
                }
                if (prevOptions.onLineItemsChange != null && options.onLineItemsChange !== prevOptions.onLineItemsChange) {
                    console.warn('Unsupported prop change on EmbeddedCheckoutProvider: You cannot change the onLineItemsChange option after setting it.');
                }
            }
        }["EmbeddedCheckoutProvider.useEffect"], [
            prevOptions,
            options
        ]);
        return /*#__PURE__*/ React.createElement(EmbeddedCheckoutContext.Provider, {
            value: ctx
        }, children);
    };
    var EmbeddedCheckoutClientElement = function EmbeddedCheckoutClientElement(_ref) {
        var id = _ref.id, className = _ref.className;
        var _useEmbeddedCheckoutC = useEmbeddedCheckoutContext(), embeddedCheckout = _useEmbeddedCheckoutC.embeddedCheckout;
        var isMounted = React.useRef(false);
        var domNode = React.useRef(null);
        React.useLayoutEffect({
            "EmbeddedCheckoutClientElement.useLayoutEffect": function() {
                if (!isMounted.current && embeddedCheckout && domNode.current !== null) {
                    embeddedCheckout.mount(domNode.current);
                    isMounted.current = true;
                } // Clean up on unmount
                return ({
                    "EmbeddedCheckoutClientElement.useLayoutEffect": function() {
                        if (isMounted.current && embeddedCheckout) {
                            try {
                                embeddedCheckout.unmount();
                                isMounted.current = false;
                            } catch (e) {
                            // Parent effects are destroyed before child effects, so
                            // in cases where both the EmbeddedCheckoutProvider and
                            // the EmbeddedCheckout component are removed at the same
                            // time, the embeddedCheckout instance will be destroyed,
                            // which causes an error when calling unmount.
                            }
                        }
                    }
                })["EmbeddedCheckoutClientElement.useLayoutEffect"];
            }
        }["EmbeddedCheckoutClientElement.useLayoutEffect"], [
            embeddedCheckout
        ]);
        return /*#__PURE__*/ React.createElement("div", {
            ref: domNode,
            id: id,
            className: className
        });
    }; // Only render the wrapper in a server environment.
    var EmbeddedCheckoutServerElement = function EmbeddedCheckoutServerElement(_ref2) {
        var id = _ref2.id, className = _ref2.className;
        // Validate that we are in the right context by calling useEmbeddedCheckoutContext.
        useEmbeddedCheckoutContext();
        return /*#__PURE__*/ React.createElement("div", {
            id: id,
            className: className
        });
    };
    var EmbeddedCheckout = isServer ? EmbeddedCheckoutServerElement : EmbeddedCheckoutClientElement;
    /**
   * @docs https://stripe.com/docs/stripe-js/react#usestripe-hook
   */ var useStripe = function useStripe() {
        var _useElementsOrCheckou = useElementsOrCheckoutSdkContextWithUseCase('calls useStripe()'), stripe = _useElementsOrCheckou.stripe;
        return stripe;
    };
    /**
   * Requires beta access:
   * Contact [Stripe support](https://support.stripe.com/) for more information.
   *
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var AuBankAccountElement = createElementComponent('auBankAccount', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var CardElement = createElementComponent('card', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var CardNumberElement = createElementComponent('cardNumber', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var CardExpiryElement = createElementComponent('cardExpiry', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var CardCvcElement = createElementComponent('cardCvc', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var FpxBankElement = createElementComponent('fpxBank', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var IbanElement = createElementComponent('iban', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var IdealBankElement = createElementComponent('idealBank', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var P24BankElement = createElementComponent('p24Bank', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var EpsBankElement = createElementComponent('epsBank', isServer);
    var PaymentElement = createElementComponent('payment', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var ExpressCheckoutElement = createElementComponent('expressCheckout', isServer);
    /**
   * Requires beta access:
   * Contact [Stripe support](https://support.stripe.com/) for more information.
   */ var CurrencySelectorElement = createElementComponent('currencySelector', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var PaymentRequestButtonElement = createElementComponent('paymentRequestButton', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var LinkAuthenticationElement = createElementComponent('linkAuthentication', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var AddressElement = createElementComponent('address', isServer);
    /**
   * @deprecated
   * Use `AddressElement` instead.
   *
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var ShippingAddressElement = createElementComponent('shippingAddress', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var PaymentMethodMessagingElement = createElementComponent('paymentMethodMessaging', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var AffirmMessageElement = createElementComponent('affirmMessage', isServer);
    /**
   * @docs https://stripe.com/docs/stripe-js/react#element-components
   */ var AfterpayClearpayMessageElement = createElementComponent('afterpayClearpayMessage', isServer);
    exports1.AddressElement = AddressElement;
    exports1.AffirmMessageElement = AffirmMessageElement;
    exports1.AfterpayClearpayMessageElement = AfterpayClearpayMessageElement;
    exports1.AuBankAccountElement = AuBankAccountElement;
    exports1.CardCvcElement = CardCvcElement;
    exports1.CardElement = CardElement;
    exports1.CardExpiryElement = CardExpiryElement;
    exports1.CardNumberElement = CardNumberElement;
    exports1.CheckoutProvider = CheckoutProvider;
    exports1.CurrencySelectorElement = CurrencySelectorElement;
    exports1.Elements = Elements;
    exports1.ElementsConsumer = ElementsConsumer;
    exports1.EmbeddedCheckout = EmbeddedCheckout;
    exports1.EmbeddedCheckoutProvider = EmbeddedCheckoutProvider;
    exports1.EpsBankElement = EpsBankElement;
    exports1.ExpressCheckoutElement = ExpressCheckoutElement;
    exports1.FpxBankElement = FpxBankElement;
    exports1.IbanElement = IbanElement;
    exports1.IdealBankElement = IdealBankElement;
    exports1.LinkAuthenticationElement = LinkAuthenticationElement;
    exports1.P24BankElement = P24BankElement;
    exports1.PaymentElement = PaymentElement;
    exports1.PaymentMethodMessagingElement = PaymentMethodMessagingElement;
    exports1.PaymentRequestButtonElement = PaymentRequestButtonElement;
    exports1.ShippingAddressElement = ShippingAddressElement;
    exports1.useCheckout = useCheckout;
    exports1.useElements = useElements;
    exports1.useStripe = useStripe;
});
}}),
}]);

//# sourceMappingURL=_b6d03577._.js.map