(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/placeholder/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ComingSoon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ComingSoon() {
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const starsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    // Stars animation
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ComingSoon.useEffect": ()=>{
            const canvas = canvasRef.current;
            if (!canvas) return;
            const ctx = canvas.getContext("2d");
            if (!ctx) return;
            const resizeCanvas = {
                "ComingSoon.useEffect.resizeCanvas": ()=>{
                    canvas.width = window.innerWidth;
                    canvas.height = window.innerHeight;
                }
            }["ComingSoon.useEffect.resizeCanvas"];
            const createStars = {
                "ComingSoon.useEffect.createStars": ()=>{
                    starsRef.current = [];
                    for(let i = 0; i < 150; i++){
                        starsRef.current.push({
                            x: Math.random() * canvas.width,
                            y: Math.random() * canvas.height,
                            radius: Math.random() * 1.5 + 0.3,
                            speed: Math.random() * 0.3 + 0.1,
                            opacity: Math.random() * 0.8 + 0.2
                        });
                    }
                }
            }["ComingSoon.useEffect.createStars"];
            const animateStars = {
                "ComingSoon.useEffect.animateStars": ()=>{
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    for (let star of starsRef.current){
                        ctx.beginPath();
                        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
                        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
                        ctx.fill();
                        star.y += star.speed;
                        if (star.y > canvas.height) {
                            star.y = 0;
                            star.x = Math.random() * canvas.width;
                        }
                    }
                    requestAnimationFrame(animateStars);
                }
            }["ComingSoon.useEffect.animateStars"];
            resizeCanvas();
            createStars();
            animateStars();
            window.addEventListener("resize", resizeCanvas);
            return ({
                "ComingSoon.useEffect": ()=>window.removeEventListener("resize", resizeCanvas)
            })["ComingSoon.useEffect"];
        }
    }["ComingSoon.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-e55d787b73d662cb" + " " + 'coming-soon-container',
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                ref: canvasRef,
                className: "jsx-e55d787b73d662cb" + " " + 'stars-canvas'
            }, void 0, false, {
                fileName: "[project]/src/app/placeholder/page.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-e55d787b73d662cb" + " " + 'content',
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-e55d787b73d662cb" + " " + 'logo',
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-e55d787b73d662cb" + " " + 'orb-glow'
                            }, void 0, false, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 65,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-e55d787b73d662cb" + " " + 'orb'
                            }, void 0, false, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/placeholder/page.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "jsx-e55d787b73d662cb" + " " + 'title uppercase',
                        children: "Speak to Her"
                    }, void 0, false, {
                        fileName: "[project]/src/app/placeholder/page.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-e55d787b73d662cb" + " " + 'coming-soon-text',
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "jsx-e55d787b73d662cb",
                                children: "Coming Soon..."
                            }, void 0, false, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-e55d787b73d662cb" + " " + 'subtitle',
                                children: "Divine wisdom awaits"
                            }, void 0, false, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/placeholder/page.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-e55d787b73d662cb" + " " + 'description'
                    }, void 0, false, {
                        fileName: "[project]/src/app/placeholder/page.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-e55d787b73d662cb" + " " + 'features',
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-e55d787b73d662cb" + " " + 'feature',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-e55d787b73d662cb" + " " + 'feature-icon',
                                        children: "🕊️"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/placeholder/page.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-e55d787b73d662cb",
                                        children: "Divine Guidance"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/placeholder/page.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-e55d787b73d662cb" + " " + 'feature',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-e55d787b73d662cb" + " " + 'feature-icon',
                                        children: "✨"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/placeholder/page.tsx",
                                        lineNumber: 84,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-e55d787b73d662cb",
                                        children: "Sacred Wisdom"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/placeholder/page.tsx",
                                        lineNumber: 85,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-e55d787b73d662cb" + " " + 'feature',
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-e55d787b73d662cb" + " " + 'feature-icon',
                                        children: "💫"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/placeholder/page.tsx",
                                        lineNumber: 88,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-e55d787b73d662cb",
                                        children: "Spiritual Connection"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/placeholder/page.tsx",
                                        lineNumber: 89,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/placeholder/page.tsx",
                                lineNumber: 87,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/placeholder/page.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/placeholder/page.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "e55d787b73d662cb",
                children: ".coming-soon-container.jsx-e55d787b73d662cb{background:linear-gradient(135deg,#000 0%,#1a1a1a 50%,#000 100%);justify-content:center;align-items:center;width:100%;min-height:100vh;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;display:flex;position:relative;overflow:hidden}.stars-canvas.jsx-e55d787b73d662cb{z-index:1;width:100%;height:100%;position:absolute;top:0;left:0}.content.jsx-e55d787b73d662cb{z-index:2;text-align:center;color:#fff;max-width:600px;padding:2rem;position:relative}.logo.jsx-e55d787b73d662cb{margin-bottom:2rem;position:relative}.orb.jsx-e55d787b73d662cb{background:radial-gradient(circle,#fffc 0%,#ffffff4d 50%,#0000 100%);border-radius:50%;width:80px;height:80px;margin:0 auto;animation:3s ease-in-out infinite pulse;position:relative}.orb-glow.jsx-e55d787b73d662cb{background:radial-gradient(circle,#ffffff1a 0%,#0000 70%);border-radius:50%;width:120px;height:120px;animation:4s ease-in-out infinite glow;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}@keyframes pulse{0%,to{opacity:.8;transform:scale(1)}50%{opacity:1;transform:scale(1.1)}}@keyframes glow{0%,to{opacity:.3;transform:translate(-50%,-50%)scale(1)}50%{opacity:.6;transform:translate(-50%,-50%)scale(1.2)}}.title.jsx-e55d787b73d662cb{letter-spacing:-.03em;text-shadow:0 0 20px #ffffff4d;background:linear-gradient(45deg,#fff,#f0f0f0);-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:1rem;font-size:3.5rem;font-weight:700}.coming-soon-text.jsx-e55d787b73d662cb{margin-bottom:2rem}.coming-soon-text.jsx-e55d787b73d662cb h2.jsx-e55d787b73d662cb{color:#f0f0f0;margin-bottom:.5rem;font-size:2rem;font-weight:300}.subtitle.jsx-e55d787b73d662cb{color:#ccc;font-size:1.1rem;font-style:italic}.description.jsx-e55d787b73d662cb{margin-bottom:3rem;line-height:1.6}.description.jsx-e55d787b73d662cb p.jsx-e55d787b73d662cb{color:#ddd;max-width:500px;margin:0 auto;font-size:1.1rem}.features.jsx-e55d787b73d662cb{flex-wrap:wrap;justify-content:center;gap:2rem;margin-bottom:3rem;display:flex}.feature.jsx-e55d787b73d662cb{color:#ccc;flex-direction:column;align-items:center;gap:.5rem;display:flex}.feature-icon.jsx-e55d787b73d662cb{font-size:1.5rem}.notify-section.jsx-e55d787b73d662cb{margin-top:2rem}.notify-section.jsx-e55d787b73d662cb p.jsx-e55d787b73d662cb{color:#ddd;margin-bottom:1rem;font-size:1rem}.notify-form.jsx-e55d787b73d662cb{flex-wrap:wrap;justify-content:center;gap:.5rem;max-width:400px;margin:0 auto;display:flex}.email-input.jsx-e55d787b73d662cb{color:#fff;backdrop-filter:blur(10px);background:#ffffff0d;border:1px solid #fff3;border-radius:8px;flex:1;min-width:250px;padding:.75rem 1rem;font-size:1rem}.email-input.jsx-e55d787b73d662cb::placeholder{color:#fff9}.email-input.jsx-e55d787b73d662cb:focus{border-color:#ffffff80;outline:none;box-shadow:0 0 0 2px #ffffff1a}.notify-btn.jsx-e55d787b73d662cb{color:#fff;cursor:pointer;backdrop-filter:blur(10px);background:linear-gradient(45deg,#ffffff1a,#ffffff0d);border:1px solid #fff3;border-radius:8px;padding:.75rem 1.5rem;font-size:1rem;transition:all .3s}.notify-btn.jsx-e55d787b73d662cb:hover{background:linear-gradient(45deg,#fff3,#ffffff1a);border-color:#fff6;transform:translateY(-1px)}@media (width<=768px){.title.jsx-e55d787b73d662cb{font-size:2.5rem}.coming-soon-text.jsx-e55d787b73d662cb h2.jsx-e55d787b73d662cb{font-size:1.5rem}.features.jsx-e55d787b73d662cb{gap:1rem}.notify-form.jsx-e55d787b73d662cb{flex-direction:column;align-items:center}.email-input.jsx-e55d787b73d662cb{min-width:280px}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/placeholder/page.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(ComingSoon, "1UxxvqGDCyqK+E67HH70tEHk5Y4=");
_c = ComingSoon;
var _c;
__turbopack_context__.k.register(_c, "ComingSoon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_placeholder_page_tsx_9a9fff68._.js.map